<?php
namespace app\index\controller;
use think\Controller;
use \think\Db;

class Index extends Controller {
    public function __construct(){
        parent::__construct();
    }

    public function index()
    {
        $this->checkLogin();
        $data = [];
        return view('index', $data);
    }

    public function checkLogin() {
        $client = session(CLIENT);
        if(empty($client)) {
            $this->redirect('index/login');
        }
    }

    public function login(){
        $param = input('param.');
        $data = [];
        return view('login/index', $data);
    }

    public function doLogin(){
        $param = input('param.');

        $username = $param['username'];
        $password = md5($param['password']);

        $client = db('m_client')->where(['username' => $username])->find();

        if(empty($client)) {
            return json(['code' => 1,'msg' => 'username is not exist']);
        }

        if($password != $client['password']) {
            return json(['code' => 1,'msg' => 'password is incorrect']);
        }
        
        unset($client['password']);
        session(CLIENT, $client);
        return json(['code' => 0,'msg' => 'login success']);
    }

    public function logOut(){
        session(CLIENT, NULL);
        $this->redirect('index/login');
    }

    public function register(){
        $param = input('param.');
        $data = [];
        return view('register/index', $data);
    }

    public function doRegister(){
        $param = input('param.');

        $username = $param['username'];
        $password = md5($param['password']);
        $email = $param['email'];

        $data['username'] = $username;
        $data['password'] = $password;
        $data['email'] = $email;
        $data['add_time'] = time();
        $pkid = db('m_client')->insertGetId( $data);
        if($pkid > 0) {
            $client = db('m_client')->where(['id' => $pkid])->find();
            unset($client['password']);
            session(CLIENT, $client);
            return json(['code' => 0,'msg' => 'register success']);
        } else {
            return json(['code' => 1,'msg' => 'register fail']);
        }
    }

    public function manage(){
        $param = input('param.');
        $data = [];
        $this->checkLogin();

        $client = session(CLIENT);
        $info = db('m_client')->where(['id' => $client['id']])->find();
        $this->assign('states',$this->getStates());
        return view('manage/index', $info);
    }

    public function doManage(){
        $param = input('param.');
        $data = [];
        $this->checkLogin();

        $client = session(CLIENT);
        $id = $client['id'];

        $data['fullname'] = $param['fullname'];
        $data['address1'] = $param['address1'];
        $data['address2'] = $param['address2'];
        $data['city'] = $param['city'];
        $data['state'] = $param['state'];
        $data['zipcode'] = $param['zipcode'];

        $ret = db('m_client')->where(['id' => $id])->update( $data);
        if($ret > 0) {
            return json(['code' => 0,'msg' => 'save success']);
        } else {
            return json(['code' => 1,'msg' => 'save fail']);
        }
    }

    public function fuelQf(){
        $param = input('param.');
        $this->checkLogin();

        $data = [];
        return view('fuelQf/index', $data);
    }

    public function calcQuotePrice() {
        $param = input('param.');
        $this->checkLogin();
        $client = session(CLIENT);

        $gallons = $param['gallons'];
        $quote_date = $param['quote_date'];

        // $month = date($quote_date);
        $month = date('m',strtotime($quote_date));

        // 现在价格
        $current_price = 1.5;

        // 产地因素(%)
        $location_factor = 0.04;
        if($client['state'] == 'TX') {
            $location_factor = 0.02;
        }

        // 历史利率因素
        $rate_history_factor = 0;
        $new_client = db('m_user_quote_history')->where(['client_id' => $client['id']])->find();
        if(empty($new_client)) {
            $rate_history_factor = 0.01;
        }

        // 需要的加仑因素
        $gallons_requested_factor = 0.03;
        if($gallons >= 1000) {
            $gallons_requested_factor = 0.02;
        }

        // 公司利润因素
        $company_profit_factor = 0.1;

        // 季节汇率波动 夏天4%，别的季节3%
        $rate_fluctuation = 0.03;
        $summer = ['06','07','08'];
        if(in_array($month, $summer)) {
            $rate_fluctuation = 0.04;
        }

        //保证金=现在价格*（产地因素-历史利率因素+需要的加仑因素+公司利润因素+汇率波动）
        $margin = $current_price * ($location_factor - $rate_history_factor + $gallons_requested_factor + $company_profit_factor + $rate_fluctuation);

        // 预测价格 建议价格=现在价格+保证金
        $suggested_price = $current_price + $margin;

        // 需要支付的金额
        $total_amount = $suggested_price * $gallons;

        $data['suggested_price'] = $suggested_price;
        $data['total_amount'] = $total_amount;

        return json(['code' => 0,'msg' => 'ok','data' => $data]);
    }

    public function saveQuote(){
        $param = input('param.');
        $this->checkLogin();
        $client = session(CLIENT);

        $gallons = $param['gallons'];
        $quote_date = $param['quote_date'];
        $suggested_price = $param['suggested_price'];

        $data['client_id'] = $client['id'];
        $data['gallons'] = $gallons;
        $data['quote_date'] = $quote_date;
        $data['suggested_price'] = $suggested_price;

        $where['client_id'] = $client['id'];
        $where['gallons'] = $gallons;
        $where['quote_date'] = $quote_date;

        $history = db('m_user_quote_history')->where($where)->find();
        if(empty($history)) {
            $data['add_time'] = time();
            db('m_user_quote_history')->insert($data);
        } else {
            $id = $history['id'];
            db('m_user_quote_history')->where(['id' => $id])->update($data);
        }

        return json(['code' => 0,'msg' => 'save success']);
    }

    public function fuelQh(){
        $param = input('param.');
        $this->checkLogin();

        $client = session(CLIENT);
        $client_id = $client['id'];

        $list = db('m_user_quote_history')->where(['client_id' => $client_id])->order('id desc')->select();
        $data = [];
        $this->assign('list',$list);
        return view('fuelQh/index', $data);
    }


    // state list
    private function getStates() {
        $states = ['AL',
                    'AK',
                    'AR',
                    'AZ',
                    'CA',
                    'CO',
                    'CT',
                    'DC',
                    'DE',
                    'FL',
                    'GA',
                    'HI',
                    'IA',
                    'ID',
                    'IL',
                    'IN',
                    'KS',
                    'KY',
                    'LA',
                    'MA',
                    'MD',
                    'ME',
                    'MI',
                    'MN',
                    'MO',
                    'MS',
                    'MT',
                    'NC',
                    'NE',
                    'NH',
                    'NJ',
                    'NM',
                    'NV',
                    'NY',
                    'ND',
                    'OH',
                    'OK',
                    'OR',
                    'PA',
                    'RI',
                    'SC',
                    'SD',
                    'TN',
                    'TX',
                    'UT',
                    'VT',
                    'VA',
                    'WA',
                    'WI',
                    'WV',
                    'WY'];
        return $states;
    }
}
