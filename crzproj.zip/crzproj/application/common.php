<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------

// 应用公共文件

/**
 * 获取百度坐标
 */
function getBaiduPos( $address = ''){
	$url = 'http://api.map.baidu.com/geocoder/v2/?output=json&address='. $address .'&ak=' . BAIDU_API_KEY;
	$content = json_decode( file_get_contents($url),true);
	if( ! empty($content) && isset($content['result']['location'])){
		//经度
		$data['longitude'] = $content['result']['location']['lng'];
		//维度
		$data['latitude'] = $content['result']['location']['lat'];
		return ['status' => 1, 'data' => $data];
	}
	return ['status' => 0, 'msg' => '读取地址出错'];
}

/**
 * 导出数据
 * @param $file_name 文件名称
 * @param $excel_title excel列名称数组
 * @param $rows 数据源
 */
function export_csv($file_name, $excel_title, $rows){
	ini_set('memory_limit', '4096M');
	header('Content-Type: application/vnd.ms-execl');
    header('Content-Disposition: attachment;filename="' . $file_name . '.csv"');
    header('Cache-Control: max-age=0');
	$title_array = [];
	foreach ($excel_title as $col => $title) {
		# code...
		$title_array[$col] = isset( $excel_title[$col]) ? iconv( 'UTF-8', 'GB2312//IGNORE',  $excel_title[$col] )  : '';
	}

    $fp = fopen('php://output', 'a');
    //开始写入
    fputcsv($fp, $title_array);
    $push_count = 0;
	foreach ($rows as $key => $row) {
        $r = [];
        foreach ($title_array as $col => $name) {
        	$val = isset($row[$col]) ? $row[$col] : '';
        	if( is_numeric($val)){
        		$val = '`' . $val;
        	}
            $r[$col] = iconv( 'UTF-8', 'GB2312//IGNORE', $val ) ;
        }
        fputcsv($fp, $r);
        $push_count ++;
        if( $push_count >= 1000){
        	ob_flush();
    		flush();
    		$push_count = 0;
        }
    }
    exit;
}

/**
 * 获取商户权限
 * @param $field 字段名称
 * @param $where where 条件
 */
function getMerWhere($field,& $where){
    $admin = session(ADMIN);
    
    $merchant_ids = $admin['merchant_ids'];
    if($merchant_ids != ALL){
        $where[$field] = ['in',$merchant_ids];
    }
}

/**
 * 获取商户门店权限
 * @param $file_name 文件名称
 * @param $excel_title excel列名称数组
 * @param $rows 数据源
 */
function getShopWhere($field,& $where){
    $admin = session(ADMIN);
    
    $shop_ids = $admin['shop_ids'];
    if($shop_ids != ALL){
        $where[$field] = ['in',$shop_ids];
    }
}

/**
 * 获取精确到微秒的时间戳
 */
function getMillisecond() { 
    list($s1, $s2) = explode(' ', microtime()); 
    return (float)sprintf('%.0f', (floatval($s1) + floatval($s2)) * 1000); 
}