<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:71:"D:\xampp\htdocs\zoemp\public/../application/admin\view\kiosk\index.html";i:1573722593;s:64:"D:\xampp\htdocs\zoemp\application\admin\view\library\header.html";i:1552474293;s:62:"D:\xampp\htdocs\zoemp\application\admin\view\library\menu.html";i:1539761895;s:64:"D:\xampp\htdocs\zoemp\application\admin\view\library\footer.html";i:1531464212;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>影院广告管理</title>
    <link rel="stylesheet" href="/static/layui/css/layui.css">
    <script src="/static/js/jquery.min.js"></script>
    <script src="/static/layui/layui.js"></script>
    <script>
        var jquery,element;
        layui.use(['element', 'jquery'], function(){
            element = layui.element;
            jquery = layui.jquery;
        });

        function logout(){
            var param = {};
            jquery.post('/admin/login/doLogout', param,function(response){
                if( response.status > 0){
                    window.location.href = '/admin';
                    return true;
                }
            },'JSON')
        }
    </script>
</head>
<body class="layui-layout-body">
    <div class="layui-layout layui-layout-admin">
        <div class="layui-header">
            <div class="layui-logo">
                <img src="/static/images/nav-logo.png"/>
            </div>
            <!-- 头部区域（可配合layui已有的水平导航） -->
            <ul class="layui-nav layui-layout-right">
                <li class="layui-nav-item">
                    <a href="javascript:;">
                        <img src="http://t.cn/RCzsdCq" class="layui-nav-img">
                    <?php echo $admin['admin_name']; ?>
                    </a>
                </li>
                <li class="layui-nav-item"><a href="#" onclick="logout()">登出</a></li>
            </ul>
        </div>

<div class="layui-side layui-bg-black">
    <div class="layui-side-scroll">
        <!-- 左侧导航区域（可配合layui已有的垂直导航） -->
        <ul class="layui-nav layui-nav-tree"  lay-filter="test">
            <?php if($menu_list): foreach($menu_list as $menu): ?>
                    <li class="layui-nav-item layui-nav-itemed">
                        <a class="" href="javascript:;"><?php echo $menu['module_name']; ?></a>
                        <?php if($menu['parents'] != ""): ?>
                            <dl class="layui-nav-child">
                                <?php foreach($menu['parents'] as $childMenu): ?>
                                    <dd style="padding-left:1.2rem;" class="<?php if( stripos( $php_self, $childMenu['module_action']) !== false) echo 'layui-this'?>">
                                        <a href="<?php echo $childMenu['module_action']; ?>" ><?php echo $childMenu['module_name']; ?></a>
                                    </dd>
                                <?php endforeach; ?>
                            </dl>
                        <?php endif; ?>
                    </li>
                <?php endforeach; endif; ?>
          <!--   <li class="layui-nav-item layui-nav-itemed">
                <a class="" href="javascript:;">所有商品</a>
                <dl class="layui-nav-child">
                    <dd><a href="javascript:;">列表一</a></dd>
                    <dd><a href="javascript:;">列表二</a></dd>
                    <dd><a href="javascript:;">列表三</a></dd>
                    <dd><a href="">超链接</a></dd>
                </dl>
            </li>

            <li class="layui-nav-item">
                <a href="javascript:;">解决方案</a>
                <dl class="layui-nav-child">
                    <dd><a href="javascript:;">列表一</a></dd>
                    <dd><a href="javascript:;">列表二</a></dd>
                    <dd><a href="">超链接</a></dd>
                </dl>
            </li>
            
            <li class="layui-nav-item"><a href="">云市场</a></li>
            <li class="layui-nav-item"><a href="">发布商品</a></li> -->
      </ul>
    </div>
</div>

<style type="text/css">
    .layui-btn{background-color: #1e9fff;}    
    .layui-input-c{width: 400px;}
    .lyui_icon_big{font-size: 26px;color: #12a0ff;cursor: pointer;}
</style>>

<link rel="stylesheet" href="/static/css/multiple-select.css" />
<div class="layui-body" style="bottom: 0;">
    <!-- 内容主体区域 -->
    <div style="padding: 15px;">
        <div class="layui-row">
            <span class="layui-breadcrumb">
                <a href="/admin/index">首页</a>
                <a href="javascript:void(0)">影院终端列表</a>
            </span>
        </div>
        
        <div class="layui-row" style="padding-top: 15px;">
            <div class="layui-form" style="float:left;">
                <div class="layui-form-item">
                    <div class="layui-inline">
                        <label class="layui-form-label">名称：</label>
                        <div class="layui-input-block">
                          <input type="text" placeholder="终端名称|编号"  class="layui-input" id="keywords">
                        </div>
                    </div>
                
                    <div class="layui-inline">
                        <button class="layui-btn layui-btn-normal" onclick="search()">
                        <i class="layui-icon">&#xe615;</i>
                    </button>
                    </div>
                </div>
            </div>
            <div style="float:right">
                <button class="layui-btn layui-btn-normal" style="margin-left: 25px;" onclick="dlgAdmin(0)">
                    添加
                </button>
            </div>
        </div>

        <div class="layui-row">
            <table id="tableList" lay-filter="tableList"></table>
        </div>

        
    </div>
</div>

<div id="form_detail" style="display: none;">
<form class="layui-form" action="">
    <div style="margin-top:15px;margin-left:15px;">
        <div class="layui-form-item">
            <div class="layui-block">
                <label class="layui-form-label">终端名称：</label>
                <div class="layui-input-block">
                  <input type="text" placeholder="请输入终端名称"  class="layui-input layui-input-c" id="kiosk_name">
                </div>
            </div>
        </div>
        <!-- <div class="layui-form-item">
            <div class="layui-block">
                <label class="layui-form-label">终端编号：</label>
                <div class="layui-input-block">
                  <input type="text" placeholder="请输入终端编号"  class="layui-input layui-input-c" id="kiosk_no">
                </div>
            </div>
        </div> -->
        <div class="layui-form-item">
            <label class="layui-form-label">终端设备：</label>
            <div class="layui-input-block" style="width: 400px;">
                 <select id="dlg_kiosk_list" lay-filter="kiosk_type" lay-search="">
                     <option value="1">自助取票机</option>
                     <option value="2">自助验票机</option>
                 </select>
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">APK类型：</label>
            <div class="layui-input-block" style="width: 400px;">
                 <select id="dlg_apk_type" lay-filter="apk_type" lay-search="">
                 </select>
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">影院：</label>
            <div class="layui-input-block" style="width: 400px;">
                 <select id="dlg_cinema_list" lay-filter="cinema_list" lay-search=""></select>
            </div>
        </div>
    </div>
    </form>
</div>

<div id="kiosk_hall" style="display: none;">
    <form class="layui-form" action="javascript:void(0)" style="margin: 15px;">
        <table class="layui-table">
        <colgroup>
          <col width="50">
          <col width="150">
          <col width="50">
        </colgroup>
        <thead>
          <tr>
            <th>编号</th>
            <th>影厅名称</th>
            <th>是否选中</th>
          </tr> 
        </thead>
        <tbody id="tbodyContent">
         
        </tbody>
      </table>
  </form>
</div>
  

	</div>
</body>
</html>
<script src="/static/js/jquery.min.js"></script>
<script src="/static/js/multiple-select.js"></script>
<script>
var table,form,jquery,upload,img_path,mer_id;
var g_pkid = 0;
layui.use(['table','form', 'jquery','upload'], function(){
    table = layui.table;
    form = layui.form;
    jquery = layui.jquery;
    upload = layui.upload;

    jquery.ajaxSetup({
        async: false
    });
    //加载配置
    loadConfig();

    table.render({
        id : 'tableList',
        elem: '#tableList',
        height: jquery(window).height() - 185,
        url: '/admin/kiosk/getListPage/',
        limits:  <?php  echo json_encode( config('paginate.page_list'))?>,
        limit: <?php  echo  config('paginate.list_rows')?>,
        page: true, //开启分页,
        loading : true,
        cols: [[ 
            {field: 'kiosk_id', title: '序号',width:80,align:'center'},
            {field: 'shop_name', title: '影院名称',align:'center'},
            {field: 'kiosk_name', title: '终端名称',width : 190,align:'center'},
            {field: 'kiosk_no', title: '终端编号',width : 90,align:'center'},
            {field: 'add_time_format', title: '添加时间',width : 170,align:'center'},
            {field: 'hall_check', title: '影厅检查',align:'center',width:90,templet:function(d){
                var checked = d.hall_check > 0 ? 'checked' : '';
                return '<input type="checkbox" value="' + d.kiosk_id + '" lay-filter="hallcheck" lay-skin="switch" lay-text="ON|OFF" '+ checked +'>';
            }},
            {field: 'status', title: '状态',align:'center',width:90,templet:function(d){
                var checked = d.status > 0 ? 'checked' : '';
                return '<input type="checkbox" value="' + d.kiosk_id + '" lay-filter="valid" lay-skin="switch" lay-text="ON|OFF" '+ checked +'>';
            }},
            {title:'操作',align:'center',width:100,toolbar:'#tool'}
        ]]
    });

      //设定文件大小限制
      upload.render({
        elem: '#imageUpload'
        ,url: '/admin/base/uploadImage/?dir=logo'
        ,size: 1024 //限制文件大小，单位 KB
        ,done: function(res){
          layer.open({
                content : res.msg,
                end:function(){
                    if( res.status >0){
                        img_path = res.data.path;
                        $('#logo_img').attr('src', img_path);
                    }
                }
            })
        }
      });

    table.on('tool(tableList)', function(obj){ //注：tool是工具条事件名，test是table原始容器的属性 lay-filter="对应的值"
        var data = obj.data; //获得当前行数据
        var layEvent = obj.event; //获得 lay-event 对应的值（也可以是表头的 event 参数对应的值）
        var tr = obj.tr; //获得当前行 tr 的DOM对象
        if( layEvent == 'edit'){
            dlgAdmin(data.kiosk_id);
        } else if(layEvent === 'view'){
            dlgKioskHall(data.kiosk_id);
            //alert(data.kiosk_id);
        } else if(layEvent === 'del'){ //删除
            layer.confirm('您确定要删除终端名称 ['+ data.kiosk_name +'] 吗？', function(index){
                del(data);
                //obj.del(); //删除对应行（tr）的DOM结构，并更新缓存
                layer.close(index);
                //向服务端发送删除指令
            });
        }
    });

    table.on('edit(tableList)',function(obj){
        /* 得到修改后的值 */
        var val = obj.value;
        /* 得到所在行所有键值 */
        var data = obj.data;
        /* 得到要编辑的字段 */
        var field = obj.field;
        layer.msg('field='+data.shop_id);

        updateCol(data.kiosk_id,field,val);
    });

    form.on('switch(valid)', function(obj){
        toggleValid(obj.value,'status');
    });

    form.on('switch(hallcheck)', function(obj){
        toggleValid(obj.value,'hall_check');
    });
});

function loadConfig(){
    var param = {};
    // param.methods = 'bank|merchant|group';
    param.methods = 'cinemaList|apkList';
    param.valid_flg = '123';
    jquery.post('/admin/base/getPageConfig', param, function(response){
        if( response.status > 0){
            var resData = response.data.cinemaList,
             apkList = response.data.apkList;

            if(resData){
                let opt = '<option value="0">请选择</option>';
                for (let i = 0; i < resData.length; i++) {
                    opt += '<option value="'+ resData[i].shop_id +'">' + resData[i].shop_name + '</option>';
                };
                $('#dlg_cinema_list').html(opt);
            }
            if(apkList){
                let opt = '<option value="0">请选择</option>';
                for (let i = 0; i < apkList.length; i++) {
                    opt += '<option value="'+ apkList[i].apk_type +'">' + apkList[i].apk_type_name + '</option>';
                };
                $('#dlg_apk_type').html(opt);
            }
            form.render();
        }
    },'JSON');
}


function search(){
    table.reload('tableList',{
        where:{
            keywords : jquery('#keywords').val(),
        }
    });
}

function updateCol(pkid,field,val){
    var param = {};
    param.kiosk_id = pkid;
    param.field = field;
    param.val = val;

    $.post('/admin/cinema/updateCol',param,function(response){
        if( response.status > 0){
            layer.msg(response.msg);
            //table.reload('tableList',{});
        } else {
            layer.msg(response.msg);
        }
    },'JSON')
}

function toggleValid(pkid,field){
    var param = {};
    param.kiosk_id = pkid;
    param.field = field;
    $.post('/admin/kiosk/toggleValid', param, function(response){
        if( response.status > 0){
            table.reload('tableList',{});
        }
    },'JSON')
}

// 查看终端绑定的影厅
function dlgKioskHall(pkid){
    var param = {};
    param.kiosk_id = pkid;

    $.post('/admin/kiosk/getHallList', param, function(response){
        var trHtml = "";
        if( response.status > 0){
            let dataList = response.data;
            dataList.forEach((v,i) => {
                let chk = v.selected == 1 ? 'checked' : '',
                trTd = `<tr><td>${i+1}</td><td>${v.hall_name}</td><td><input type="checkbox" name="switch" disabled ${chk} lay-skin="switch" lay-text="选中|未选中"></td></tr>`;
                trHtml += trTd;
            })
        } else {
            trHtml = `<tr><td align="center" colspan="3">无影厅数据</td></tr>`;
        }

        $('#tbodyContent').html(trHtml);
        form.render();

        layer.open({
            title: '查看终端绑定的影厅',
            content: jquery('#kiosk_hall'),
            type : 1,
            area: ['600px', '500px'],
            btn : ['关闭'],
            yes:function(){
                layer.closeAll();
            },
            btn2:function(){;  
            },
            success:function(index){
            }

        }); 
    },'JSON')
}

function dlgAdmin(pkid){
    layer.open({
        title: '添加/编辑 影院终端',
        content: jquery('#form_detail'),
        type : 1,
        area: ['600px', '500px'],
        btn : ['保存','关闭'],
        yes:function(){
            save(pkid);
        },
        btn2:function(){
            
        },
        success:function(index){
            getRow(pkid)
        }

    });    
}

function getRow(pkid){
    if( pkid){
        var param ={};
        param.kiosk_id = pkid
        $.post('/admin/kiosk/getRow', param, function(response){
            if( response.status > 0){
                var row = response.data.row;
                initDlgAdmin( row);
            }
            
        },'JSON');
    }else{
        initDlgAdmin({});
    }
}

function initDlgAdmin(frm){
    //基本信息
    $('#kiosk_name').val( frm.kiosk_name ? frm.kiosk_name : '');

    $('#dlg_cinema_list option[value="'+ frm.shop_id +'"]').attr('selected', true);
    $('#dlg_kiosk_list option[value="'+ frm.kiosk_type +'"]').attr('selected',true);
    $('#dlg_apk_type option[value="'+ frm.apk_type +'"]').attr('selected',true);
    form.render();
    form.render('select');
}

function save(pkid){
    var param = {};
    param.kiosk_id = pkid;
    param.kiosk_name = $.trim($('#kiosk_name').val());
    param.shop_id = $.trim($('#dlg_cinema_list').val());
    param.kiosk_type = $.trim($('#dlg_kiosk_list').val());
    param.apk_type = $.trim($('#dlg_apk_type').val());

    if(param.kiosk_name == ''){
        layer.alert("请输入终端名称");
        return;
    }

    if(param.shop_id == '0'){
        layer.alert("请选择影院");
        return;
    }
    
    $.post('/admin/kiosk/save', param, function(response){
        var msg  = response.status >0 ? '操作成功' :response.msg;
        layer.open({
            content : msg,
            end:function(){
                if(response.status >0){
                    table.reload('tableList',{});
                layer.closeAll();
                }
            }
        });
        return false;
    },'JSON')
}

function del(data){
    var param = {};
    param.kiosk_id = data.kiosk_id;
    
    $.post('/admin/kiosk/del', param, function(response){
        var msg  = response.status >0 ? '操作成功' :response.msg;
        layer.open({
            content : msg,
            end:function(){
                if(response.status >0){
                    table.reload('ad',{});
                layer.closeAll();
                }
            }
        });
        return false;
    },'JSON')
}

</script>

<!--format logo-->
<script type="text/html" id="logo">
    <a href="{{d.mer_logo}}" target="_blank"><img src="{{d.mer_logo}}" width="50"/></a>
</script>

<script type="text/html" id="tool">
    <i class="layui-icon lyui_icon_big" lay-event="edit" title="编辑">&#xe642;</i>
    <i class="layui-icon lyui_icon_big" lay-event="view" title="查看">&#xe63c;</i>
</script>
