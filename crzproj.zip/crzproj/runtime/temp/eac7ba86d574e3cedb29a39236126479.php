<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:71:"D:\xampp\htdocs\zoemp\public/../application/admin\view\group\index.html";i:1560658014;s:64:"D:\xampp\htdocs\zoemp\application\admin\view\library\header.html";i:1552474293;s:62:"D:\xampp\htdocs\zoemp\application\admin\view\library\menu.html";i:1539761895;s:64:"D:\xampp\htdocs\zoemp\application\admin\view\library\footer.html";i:1531464212;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>影院广告管理</title>
    <link rel="stylesheet" href="/static/layui/css/layui.css">
    <script src="/static/js/jquery.min.js"></script>
    <script src="/static/layui/layui.js"></script>
    <script>
        var jquery,element;
        layui.use(['element', 'jquery'], function(){
            element = layui.element;
            jquery = layui.jquery;
        });

        function logout(){
            var param = {};
            jquery.post('/admin/login/doLogout', param,function(response){
                if( response.status > 0){
                    window.location.href = '/admin';
                    return true;
                }
            },'JSON')
        }
    </script>
</head>
<body class="layui-layout-body">
    <div class="layui-layout layui-layout-admin">
        <div class="layui-header">
            <div class="layui-logo">
                <img src="/static/images/nav-logo.png"/>
            </div>
            <!-- 头部区域（可配合layui已有的水平导航） -->
            <ul class="layui-nav layui-layout-right">
                <li class="layui-nav-item">
                    <a href="javascript:;">
                        <img src="http://t.cn/RCzsdCq" class="layui-nav-img">
                    <?php echo $admin['admin_name']; ?>
                    </a>
                </li>
                <li class="layui-nav-item"><a href="#" onclick="logout()">登出</a></li>
            </ul>
        </div>

<div class="layui-side layui-bg-black">
    <div class="layui-side-scroll">
        <!-- 左侧导航区域（可配合layui已有的垂直导航） -->
        <ul class="layui-nav layui-nav-tree"  lay-filter="test">
            <?php if($menu_list): foreach($menu_list as $menu): ?>
                    <li class="layui-nav-item layui-nav-itemed">
                        <a class="" href="javascript:;"><?php echo $menu['module_name']; ?></a>
                        <?php if($menu['parents'] != ""): ?>
                            <dl class="layui-nav-child">
                                <?php foreach($menu['parents'] as $childMenu): ?>
                                    <dd style="padding-left:1.2rem;" class="<?php if( stripos( $php_self, $childMenu['module_action']) !== false) echo 'layui-this'?>">
                                        <a href="<?php echo $childMenu['module_action']; ?>" ><?php echo $childMenu['module_name']; ?></a>
                                    </dd>
                                <?php endforeach; ?>
                            </dl>
                        <?php endif; ?>
                    </li>
                <?php endforeach; endif; ?>
          <!--   <li class="layui-nav-item layui-nav-itemed">
                <a class="" href="javascript:;">所有商品</a>
                <dl class="layui-nav-child">
                    <dd><a href="javascript:;">列表一</a></dd>
                    <dd><a href="javascript:;">列表二</a></dd>
                    <dd><a href="javascript:;">列表三</a></dd>
                    <dd><a href="">超链接</a></dd>
                </dl>
            </li>

            <li class="layui-nav-item">
                <a href="javascript:;">解决方案</a>
                <dl class="layui-nav-child">
                    <dd><a href="javascript:;">列表一</a></dd>
                    <dd><a href="javascript:;">列表二</a></dd>
                    <dd><a href="">超链接</a></dd>
                </dl>
            </li>
            
            <li class="layui-nav-item"><a href="">云市场</a></li>
            <li class="layui-nav-item"><a href="">发布商品</a></li> -->
      </ul>
    </div>
</div>

<style type="text/css">
    .layui-btn{background-color: #1e9fff;}
    .layui-input{width: 200px;}
    .layui-input-c{width: 400px;}
    .lyui_icon_big{font-size: 26px;color: #12a0ff;cursor: pointer;}
</style>>

<link rel="stylesheet" href="/static/css/multiple-select.css" />
<div class="layui-body" style="bottom: 0;">
    <!-- 内容主体区域 -->
    <div style="padding: 15px;">
        <div class="layui-row">
            <span class="layui-breadcrumb">
                <a href="/admin/index">首页</a>
                <a href="javascript:void(0)">组列表</a>
            </span>
        </div>
        
        <div class="layui-row" style="padding-top: 15px;">
            <div class="layui-form" style="float:left;">
                <div class="layui-form-item">
                    <div class="layui-inline">
                        <label class="layui-form-label">名称：</label>
                        <div class="layui-input-block">
                          <input type="text" placeholder="组名称" class="layui-input" id="keywords">
                        </div>
                    </div>
                
                    <div class="layui-inline">
                        <button class="layui-btn layui-btn-normal" onclick="search()">
                        <i class="layui-icon">&#xe615;</i>
                    </button>
                    </div>

                    
                </div>
            </div>
            <div style="float:right">
                <button class="layui-btn layui-btn-normal" style="margin-left: 25px;" onclick="dlgAdmin(0)">
                    添加
                </button>
            </div>
        </div>

        <div class="layui-row">
            <table id="group" lay-filter="group"></table>
        </div>

        
    </div>
</div>

<div id="form_detail" style="display: none;">
<form class="layui-form" action="">
   <fieldset class="layui-elem-field layui-field-title" style="margin: 10px 0 0 0;">
        <legend style="border: none;width: auto;">基本信息：</legend>
    </fieldset>
    <div class="layui-form-item">
        <label class="layui-form-label">组名称</label>
        <div class="layui-input-block">
            <input type="text" name="group_name" id="group_name" lay-verify="required" placeholder="请输入组名称" autocomplete="off" class="layui-input">
        </div>
    </div>     
    <div class="layui-form-item layui-form-text">
        <label class="layui-form-label">备注</label>
        <div class="layui-input-block">
            <textarea placeholder="请输入备注" class="layui-textarea" id="group_memo" name="group_memo"></textarea>
        </div>
    </div>
    <fieldset class="layui-elem-field layui-field-title"  style="margin: 10px 0 0 0;">
        <legend style="border: none;width: auto;">权限信息：</legend>
    </fieldset>
    <div class="layui-form-item layui-form-text">
        <label class="layui-form-label">全选/反选</label>
        <div class="layui-input-block">
            <input type="checkbox" name="all" class="all" onclick="checkAll()" title="全选/反选" lay-filter="chkAll" />
        </div>
    </div>
    <div class="form_modules">
        
    </div>
</form>
</div>
  

	</div>
</body>
</html>
<script src="/static/js/jquery.min.js"></script>
<script src="/static/js/multiple-select.js"></script>
<script>
var table,form,jquery,upload,img_path,mer_id;
var g_pkid = 0;
layui.use(['table','form', 'jquery','upload'], function(){
    table = layui.table;
    form = layui.form;
    jquery = layui.jquery;
    upload = layui.upload;

    jquery.ajaxSetup({
        async: false
    });
    //加载配置
    loadConfig();

    table.render({
        id : 'group',
        elem: '#group',
        height: jquery(window).height() - 185,
        url: '/admin/group/getListPage/',
        limits:  <?php  echo json_encode( config('paginate.page_list'))?>,
        limit: <?php  echo  config('paginate.list_rows')?>,
        page: true, //开启分页,
        loading : true,
        cols: [[ 
            {field: 'group_id', title: '序号',width:80,align:'center'},
            {field: 'group_name', title: '组名称',width:160,align:'center'},
            {field: 'modules', title: '关联模块',align:'center',templet:'#template_modules'},
            {field: 'add_time_format', title: '添加时间',width:160,align:'center'},
            {field: 'status', title: '状态',width:120,align:'center',templet:function(d){
                var checked = d.valid_flg > 0 ? 'checked' : '';
                return '<input type="checkbox" value="' + d.group_id + '" lay-filter="valid" lay-skin="switch" lay-text="ON|OFF" '+ checked +'>';
            }},
            {title:'操作',align:'center',width:120,toolbar:'#tool'}
        ]]
    });

      //设定文件大小限制
      upload.render({
        elem: '#imageUpload'
        ,url: '/admin/base/uploadImage/?dir=logo'
        ,size: 1024 //限制文件大小，单位 KB
        ,done: function(res){
          layer.open({
                content : res.msg,
                end:function(){
                    if( res.status >0){
                        img_path = res.data.path;
                        $('#logo_img').attr('src', img_path);
                    }
                }
            })
        }
      });

    table.on('tool(group)', function(obj){ //注：tool是工具条事件名，test是table原始容器的属性 lay-filter="对应的值"
        var data = obj.data; //获得当前行数据
        var layEvent = obj.event; //获得 lay-event 对应的值（也可以是表头的 event 参数对应的值）
        var tr = obj.tr; //获得当前行 tr 的DOM对象
        if( layEvent == 'edit'){
            dlgAdmin(data.group_id,data);
        } else if(layEvent === 'del'){ //删除
            layer.confirm('您确定要删除广告名称 ['+ data.mer_name +'] 吗？', function(index){
                del(data);
                //obj.del(); //删除对应行（tr）的DOM结构，并更新缓存
                layer.close(index);
                //向服务端发送删除指令
            });
        }
    });

    form.on('switch(valid)', function(obj){
        toggleValid(obj.value);
    }) 

    form.on('checkbox(chkAll)', function(obj){
        //这里实现勾选 
        $('.form_modules input[name=module]').each(function(index, item){
            item.checked = obj.elem.checked;
        });
        form.render('checkbox');

        //当前元素
        //var data = $(obj.elem);
        //遍历父级tr，取第一个，然后查找第二个td，取值
        //var id = data.parents('tr').first().find('td').eq(1).text();
        //var check = obj.elem.checked;
    });   
});

function loadConfig(){
    var param = {};
    // param.methods = 'bank|merchant|group';
    param.methods = 'div';
    param.div_kind = 10001;
    $.post('/admin/base/getPageConfig', param, function(response){
        // if( response.status > 0){
        //     //区分
        //     var div = response.data.div;
        //     var divOpt = '<option value="0">请选择类型</option>';
        //     for (var i = 0; i < div.length; i++) {
        //         divOpt += '<option value="'+ div[i].div_id +'">' + div[i].div_name + '</option>';
        //     };
        //     $('#dlg_ad_type').html(divOpt);
        //     form.render();
        // }
    },'JSON');
}


function search(){
    table.reload('group',{
        where:{
            keywords : $('#keywords').val(),
        }
    });
}

function toggleValid(pkid){
    var param = {};
    param.group_id = pkid;
    param.field = 'valid_flg';
    $.post('/admin/group/toggleValid', param, function(response){
        if( response.status > 0){
            table.reload('group',{});
        }
    },'JSON')
}

function dlgAdmin(pkid,data){
    layer.open({
        title: '添加/编辑 组管理',
        content: jquery('#form_detail'),
        type : 1,
        area: ['900px', '550px'],
        btn : ['保存','关闭'],
        yes:function(){
            save(pkid);
        },
        btn2:function(){
            
        },
        success:function(index){
            if(!data) data = {};
            initDlgAdmin(data);
        }

    });    
}

function getRow(pkid){
    pkid = pkid
    if( pkid){
        var param ={};
        param.mer_id = pkid
        $.post('/admin/group/getRow', param, function(response){
            if( response.status > 0){
                var row = response.data.row;
                initDlgAdmin( row);
            }
            
        },'JSON');
    }else{
        initDlgAdmin({});
    }
}

function initDlgAdmin(data){
    post_modules();
    //基本信息
    $('#group_name').val( data.group_name ? data.group_name : '');
    $('#group_memo').val( data.memo ? data.memo : '');

    if( data.modules){
        for (var i = 0; i < data.modules.length; i++) {
            var module_id = data.modules[i].module_id;
            $('.form_modules').each(function(){
                var val = $(this).val();
                if( val == module_id){
                    $(this).attr('checked','checked');
                }
            })
        }
         form.render('checkbox');
    }
}

function save(pkid){
    var param = {};
    param.group_id = pkid;
    param.group_name = $.trim($('#group_name').val());
    param.memo = $.trim($('#group_memo').val());
    
    if(param.group_name == ''){
        layer.alert("请输入组名称");
        return;
    }

    // 获取选中的分类值
    var module_arr = [];
    $('input[name=module]:checked').each(function(){
        module_arr.push($(this).val());
    });
    if(module_arr.length == 0){
        layer.alert("请选择权限模块");
        return;
        //layer.msg("还未选择分类", {icon: 7, time:1500});return;
    }
    param.module_ids = module_arr;
    $.post('/admin/group/save', param, function(response){
        var msg  = response.status >0 ? '操作成功' :response.msg;
        layer.open({
            content : msg,
            end:function(){
                if(response.status >0){
                    table.reload('group',{});
                layer.closeAll();
                }
            }
        });
        return false;
    },'JSON')
}

function del(data){
    var param = {};
    param.ad_id = data.ad_id;
    if(data.ad_path)
        param.ad_path = data.ad_path;
    
    $.post('/admin/group/del', param, function(response){
        var msg  = response.status >0 ? '操作成功' :response.msg;
        layer.open({
            content : msg,
            end:function(){
                if(response.status >0){
                    table.reload('ad',{});
                layer.closeAll();
                }
            }
        });
        return false;
    },'JSON')
}

function post_modules(){
    var param = {};
    $.post('/admin/module/treeModules', param, function(response){
        if( response.status > 0 ){
            str = '';
            var modules = response.data.modules;
            for (var i = 0; i < modules.length; i++) {
                var parents = modules[i].parents;    
                if( parents.length > 0 ){
                    str += '<div class="layui-form-item">';
                    str += '<label class="layui-form-label">' + modules[i].module_name+ '</label>';
                    str += '<div class="layui-input-block">';
                    for (var j = 0; j < parents.length; j++) {
                        str += '<input type="checkbox" value="'+ parents[j].module_id +'" name="module" title="'+ parents[j].module_name  +'" class="form_modules"><div class="layui-unselect layui-form-checkbox layui-form-checked" lay-skin=""><span class="layui-bg-blue">' + parents[j].module_name + '</span><i class="layui-icon"></i></div>';
                    }
                    str += '</div></div>';
                }
            }
            
            $('.form_modules').html(str);
            form.render('checkbox');
        }
    },'JSON')
}

</script>

<script type="text/html" id="tool">
    <i class="layui-icon lyui_icon_big" lay-event="edit" title="编辑">&#xe642;</i>
    <!-- <i class="layui-icon lyui_icon_big" lay-event="del" title="删除">&#xe640;</i> -->
</script>

<!--format modules-->
<script type="text/javascript" id="template_modules">
    {{# for(var i = 0;i<d.modules.length;i++){ }}
       {{ d.modules[i].module_name}}
    {{# } }} 
</script>
