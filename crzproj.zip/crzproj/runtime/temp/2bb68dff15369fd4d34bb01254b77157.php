<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:69:"D:\xampp\htdocs\zoemp\public/../application/admin\view\log\index.html";i:1552561153;s:64:"D:\xampp\htdocs\zoemp\application\admin\view\library\header.html";i:1552474293;s:62:"D:\xampp\htdocs\zoemp\application\admin\view\library\menu.html";i:1539761895;s:64:"D:\xampp\htdocs\zoemp\application\admin\view\library\footer.html";i:1531464212;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>影院广告管理</title>
    <link rel="stylesheet" href="/static/layui/css/layui.css">
    <script src="/static/js/jquery.min.js"></script>
    <script src="/static/layui/layui.js"></script>
    <script>
        var jquery,element;
        layui.use(['element', 'jquery'], function(){
            element = layui.element;
            jquery = layui.jquery;
        });

        function logout(){
            var param = {};
            jquery.post('/admin/login/doLogout', param,function(response){
                if( response.status > 0){
                    window.location.href = '/admin';
                    return true;
                }
            },'JSON')
        }
    </script>
</head>
<body class="layui-layout-body">
    <div class="layui-layout layui-layout-admin">
        <div class="layui-header">
            <div class="layui-logo">
                <img src="/static/images/nav-logo.png"/>
            </div>
            <!-- 头部区域（可配合layui已有的水平导航） -->
            <ul class="layui-nav layui-layout-right">
                <li class="layui-nav-item">
                    <a href="javascript:;">
                        <img src="http://t.cn/RCzsdCq" class="layui-nav-img">
                    <?php echo $admin['admin_name']; ?>
                    </a>
                </li>
                <li class="layui-nav-item"><a href="#" onclick="logout()">登出</a></li>
            </ul>
        </div>

<div class="layui-side layui-bg-black">
    <div class="layui-side-scroll">
        <!-- 左侧导航区域（可配合layui已有的垂直导航） -->
        <ul class="layui-nav layui-nav-tree"  lay-filter="test">
            <?php if($menu_list): foreach($menu_list as $menu): ?>
                    <li class="layui-nav-item layui-nav-itemed">
                        <a class="" href="javascript:;"><?php echo $menu['module_name']; ?></a>
                        <?php if($menu['parents'] != ""): ?>
                            <dl class="layui-nav-child">
                                <?php foreach($menu['parents'] as $childMenu): ?>
                                    <dd style="padding-left:1.2rem;" class="<?php if( stripos( $php_self, $childMenu['module_action']) !== false) echo 'layui-this'?>">
                                        <a href="<?php echo $childMenu['module_action']; ?>" ><?php echo $childMenu['module_name']; ?></a>
                                    </dd>
                                <?php endforeach; ?>
                            </dl>
                        <?php endif; ?>
                    </li>
                <?php endforeach; endif; ?>
          <!--   <li class="layui-nav-item layui-nav-itemed">
                <a class="" href="javascript:;">所有商品</a>
                <dl class="layui-nav-child">
                    <dd><a href="javascript:;">列表一</a></dd>
                    <dd><a href="javascript:;">列表二</a></dd>
                    <dd><a href="javascript:;">列表三</a></dd>
                    <dd><a href="">超链接</a></dd>
                </dl>
            </li>

            <li class="layui-nav-item">
                <a href="javascript:;">解决方案</a>
                <dl class="layui-nav-child">
                    <dd><a href="javascript:;">列表一</a></dd>
                    <dd><a href="javascript:;">列表二</a></dd>
                    <dd><a href="">超链接</a></dd>
                </dl>
            </li>
            
            <li class="layui-nav-item"><a href="">云市场</a></li>
            <li class="layui-nav-item"><a href="">发布商品</a></li> -->
      </ul>
    </div>
</div>

<style type="text/css">
    .layui-btn{background-color: #1e9fff;}
    .layui-input{width: 200px;}
    .layui-input-c{width: 400px;}
    .lyui_icon_big{font-size: 26px;color: #12a0ff;cursor: pointer;}
</style>>

<link rel="stylesheet" href="/static/css/multiple-select.css" />
<div class="layui-body" style="bottom: 0;">
    <!-- 内容主体区域 -->
    <div style="padding: 15px;">
        <div class="layui-row">
            <span class="layui-breadcrumb">
                <a href="/admin/index">首页</a>
                <a href="javascript:void(0)">日志列表</a>
            </span>
        </div>
        
        <div class="layui-row" style="padding-top: 15px;">
            <div class="layui-form" style="float:left;">
                <div class="layui-form-item">
                    <div class="layui-inline">
                        <label class="layui-form-label">名称：</label>
                        <div class="layui-input-block">
                          <input type="text" placeholder="方法名称" class="layui-input" id="keywords">
                        </div>
                    </div>
                
                    <div class="layui-inline">
                        <button class="layui-btn layui-btn-normal" onclick="search()">
                        <i class="layui-icon">&#xe615;</i>
                    </button>
                    </div>

                    
                </div>
            </div>
            <div style="float:right">
                <button class="layui-btn layui-btn-normal" style="margin-left: 25px;" onclick="dlgAdmin(0)">
                    添加
                </button>
            </div>
        </div>

        <div class="layui-row">
            <table id="log" lay-filter="log"></table>
        </div>

        
    </div>
</div>


	</div>
</body>
</html>
<script src="/static/js/jquery.min.js"></script>
<script src="/static/js/multiple-select.js"></script>
<script>
var table,form,jquery,upload,img_path,mer_id;
var g_pkid = 0;
layui.use(['table','form', 'jquery','upload'], function(){
    table = layui.table;
    form = layui.form;
    jquery = layui.jquery;
    upload = layui.upload;

    jquery.ajaxSetup({
        async: false
    });

    table.render({
        id : 'log',
        elem: '#log',
        height: jquery(window).height() - 185,
        url: '/admin/log/getListPage/',
        limits:  <?php  echo json_encode( config('paginate.page_list'))?>,
        limit: <?php  echo  config('paginate.list_rows')?>,
        page: true, //开启分页,
        loading : true,
        cols: [[ 
            {field: 'log_id', title: '序号',width:60,align:'center'},
            {field: 'method', title: '方法名称',align:'center'},
            {field: 'req_ip', title: 'IP地址',width : 120,align:'center'},
            {field: 'req_content', title: '请求参数',align:'center'},
            {field: 'res_content', title: '响应参数',align:'center'},
            {field: 'req_time_format', title: '请求时间',width:160,align:'center'},
            {field: 'res_time_format', title: '响应时间',width:160,align:'center'},
            {field: 'consume_time', title: '请求耗时',width:100,align:'center'}
        ]]
    });
});



function search(){
    table.reload('log',{
        where:{
            keywords : jquery('#keywords').val(),
        }
    });
}
</script>
