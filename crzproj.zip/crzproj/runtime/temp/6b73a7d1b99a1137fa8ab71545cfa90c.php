<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"D:\xampp\htdocs\crzproj\public/../application/index\view\fuelQf\index.html";i:1587694655;}*/ ?>
<!DOCTYPE htm>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>Fule Quote Form</title>
        <link rel ="stylesheet" href="/static/css/Fuel_QF.css">
        <link rel="stylesheet" href="/static/layui/css/layui.css">
    </head>
    <body>
        <form class="LG" action="" method="post">
        <h1>Fuel Quote Form</h1>
        Enter your Gallons : <input type="number" id="gallons" name="gallons" placeholder="Gallons">
        <p>Enter your Delivery Address : <input type="text" id="delivery_address" name="delivery_address" placeholder="Delivery Address"></p>
        Enter your Delivery Date: <input type="text" id="quote_date" name="quote_date" placeholder="Delivery Date" >
        <p>Suggested Price :<span id="sp_suggested_price"></span> </p>
        <p>Total Amount Due : <span id="sp_total_amount"></p>
        <input type="button" id="btnSubmit" name="btnSubmit" onclick="calcQuotePrice()" value="submit">
        <input type="button" id="btnSave" name="btnSave" disabled="disabled" value="save">
        <p class="view-history">
            <a href="fuelQh">view history</a>
        </p>
        <input type="button" id="btnHome" name="btnHome" value="Home">
        <input type="hidden" id="hd_suggested_price"></input>
        <input type="hidden" id="hd_total_amount"></input>
        </form>

        <script src="/static/js/jquery.min.js"></script>
        <script src="/static/layui/layui.js"></script>
        <script type="text/javascript">
            layui.use(['form','laydate'],function(){
                var form = layui.form;
                var laydate = layui.laydate;
  
                laydate.render({
                    elem: '#quote_date',
                    min: 0
                });
            });
            function calcQuotePrice() {
                var gallons = $.trim($('#gallons').val());
                var quote_date = $.trim($('#quote_date').val());
                if(gallons == '') {
                    layer.alert('please enter your gallons');
                    return false;  
                }

                if(quote_date == '') {
                    layer.alert('please enter your delivery date');
                    return false;  
                }
                var fd = {};
                fd.gallons = gallons;
                fd.quote_date = quote_date;
                fd.new_client = 1;
                $.post('/index/index/calcQuotePrice', fd, function(res){
                    if(res.code == 0){
                        $('#sp_suggested_price').text('$'+res.data.suggested_price);
                        $('#hd_suggested_price').val(res.data.suggested_price);
                        $('#sp_total_amount').text('$'+res.data.total_amount);
                        $('#hd_total_amount').val(res.data.total_amount);
                        $('#btnSave').removeAttr('disabled');
                        return true;
                    }else{
                        layer.alert(res.msg);
                    }
                },'JSON')
            }
            $('#btnSave').on('click',()=>{
                var gallons = $.trim($('#gallons').val());
                var quote_date = $.trim($('#quote_date').val());
                var quote_date = $.trim($('#quote_date').val());
                var delivery_address = $.trim($('#delivery_address').val());
                if(gallons == '') {
                    layer.alert('please enter your gallons');
                    return false;  
                }

                if(quote_date == '') {
                    layer.alert('please enter your delivery date');
                    return false;  
                }

                if(delivery_address == '') {
                    layer.alert('please enter your delivery address');
                    return false;  
                }

                var fd = {};
                fd.gallons = gallons;
                fd.quote_date = quote_date;
                fd.suggested_price = $('#hd_suggested_price').val();
                fd.total_amount = $('#hd_total_amount').val();
                fd.delivery_address = delivery_address;
                $.post('/index/index/saveQuote', fd, function(res){
                    if(res.code == 0){
                        layer.alert(res.msg);
                        return true;
                    }else{
                        layer.alert(res.msg);
                    }
                },'JSON')
            })
            $('#btnHome').on('click',()=>{
                window.location.href = '/index/index/main';
                return true;
            })
        </script>
    </body>
</html>

