<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"D:\xampp\htdocs\crzproj\public/../application/index\view\fuelQf\index.html";i:1587626563;}*/ ?>
<!DOCTYPE htm>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>Fule Quote Form</title>
        <link rel ="stylesheet" href="/static/css/Fuel_QF.css">
        <link rel="stylesheet" href="/static/layui/css/layui.css">
    </head>
    <body>
        <form class="LG" action="" method="post">
        <h1>Fuel Quote Form</h1>
        Enter your Gallons : <input type="number" id="gallons" name="gallons" onblur="calcQuotePrice()" placeholder="Gallons">
        <p>Delivery Address : </p>
        Enter your Delivery Date: <input type="date" id="quote_date" onblur="calcQuotePrice()" name="quote_date" >
        <p>Suggested Price :<span id="sp_suggested_price"></span> </p>
        <p>Total Amount Due : <span id="sp_total_amount"></p>
        <input type="button" id="btnSave" name="btnSave" onclick="calcQuotePrice()" value="save">
        <p class="view-history">
            <a href="fuelQh">view history</a>
        </p>
        <input type="button" id="btnLogOut" name="btnLogOut" value="Logout">
        <input type="hidden" id="hd_suggested_price"></input>
        <input type="hidden" id="hd_total_amount"></input>
        </form>

        <script src="/static/js/jquery.min.js"></script>
        <script src="/static/layui/layui.js"></script>
        <script type="text/javascript">
            layui.use('form',function(){
                var form = layui.form;
            });
            function calcQuotePrice() {
                var gallons = $.trim($('#gallons').val());
                var quote_date = $.trim($('#quote_date').val());
                if(gallons == '') {
                    // layer.alert('please enter your gallons');
                    return false;  
                }

                if(quote_date == '') {
                    // layer.alert('please your delivery date');
                    return false;  
                }
                var fd = {};
                fd.gallons = gallons;
                fd.quote_date = quote_date;
                fd.new_client = 1;
                $.post('/index/index/calcQuotePrice', fd, function(res){
                    if(res.code == 0){
                        $('#sp_suggested_price').text('$'+res.data.suggested_price);
                        $('#hd_suggested_price').val(res.data.suggested_price);
                        $('#sp_total_amount').text('$'+res.data.total_amount);
                        $('#hd_total_amount').val(res.data.total_amount);
                        return true;
                    }else{
                        layer.alert(res.msg);
                    }
                },'JSON')
            }
            $('#btnSave').on('click',()=>{
                var gallons = $.trim($('#gallons').val());
                var quote_date = $.trim($('#quote_date').val());
                if(gallons == '') {
                    layer.alert('please enter your gallons');
                    return false;  
                }

                if(quote_date == '') {
                    layer.alert('please your delivery date');
                    return false;  
                }

                var fd = {};
                fd.gallons = gallons;
                fd.quote_date = quote_date;
                fd.suggested_price = $('#hd_suggested_price').val();
                fd.total_amount = $('#hd_total_amount').val();
                $.post('/index/index/saveQuote', fd, function(res){
                    if(res.code == 0){
                        layer.alert(res.msg);
                        return true;
                    }else{
                        layer.alert(res.msg);
                    }
                },'JSON')
            })
            $('#btnLogOut').on('click',()=>{
                window.location.href = '/index/index/logOut';
                return true;
            })
        </script>
    </body>
</html>

