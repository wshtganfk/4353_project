<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:71:"D:\xampp\htdocs\zoemp\public/../application/admin\view\index\index.html";i:1552631317;s:64:"D:\xampp\htdocs\zoemp\application\admin\view\library\header.html";i:1552474293;s:62:"D:\xampp\htdocs\zoemp\application\admin\view\library\menu.html";i:1539761895;s:64:"D:\xampp\htdocs\zoemp\application\admin\view\library\footer.html";i:1531464212;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>影院广告管理</title>
    <link rel="stylesheet" href="/static/layui/css/layui.css">
    <script src="/static/js/jquery.min.js"></script>
    <script src="/static/layui/layui.js"></script>
    <script>
        var jquery,element;
        layui.use(['element', 'jquery'], function(){
            element = layui.element;
            jquery = layui.jquery;
        });

        function logout(){
            var param = {};
            jquery.post('/admin/login/doLogout', param,function(response){
                if( response.status > 0){
                    window.location.href = '/admin';
                    return true;
                }
            },'JSON')
        }
    </script>
</head>
<body class="layui-layout-body">
    <div class="layui-layout layui-layout-admin">
        <div class="layui-header">
            <div class="layui-logo">
                <img src="/static/images/nav-logo.png"/>
            </div>
            <!-- 头部区域（可配合layui已有的水平导航） -->
            <ul class="layui-nav layui-layout-right">
                <li class="layui-nav-item">
                    <a href="javascript:;">
                        <img src="http://t.cn/RCzsdCq" class="layui-nav-img">
                    <?php echo $admin['admin_name']; ?>
                    </a>
                </li>
                <li class="layui-nav-item"><a href="#" onclick="logout()">登出</a></li>
            </ul>
        </div>

<div class="layui-side layui-bg-black">
    <div class="layui-side-scroll">
        <!-- 左侧导航区域（可配合layui已有的垂直导航） -->
        <ul class="layui-nav layui-nav-tree"  lay-filter="test">
            <?php if($menu_list): foreach($menu_list as $menu): ?>
                    <li class="layui-nav-item layui-nav-itemed">
                        <a class="" href="javascript:;"><?php echo $menu['module_name']; ?></a>
                        <?php if($menu['parents'] != ""): ?>
                            <dl class="layui-nav-child">
                                <?php foreach($menu['parents'] as $childMenu): ?>
                                    <dd style="padding-left:1.2rem;" class="<?php if( stripos( $php_self, $childMenu['module_action']) !== false) echo 'layui-this'?>">
                                        <a href="<?php echo $childMenu['module_action']; ?>" ><?php echo $childMenu['module_name']; ?></a>
                                    </dd>
                                <?php endforeach; ?>
                            </dl>
                        <?php endif; ?>
                    </li>
                <?php endforeach; endif; ?>
          <!--   <li class="layui-nav-item layui-nav-itemed">
                <a class="" href="javascript:;">所有商品</a>
                <dl class="layui-nav-child">
                    <dd><a href="javascript:;">列表一</a></dd>
                    <dd><a href="javascript:;">列表二</a></dd>
                    <dd><a href="javascript:;">列表三</a></dd>
                    <dd><a href="">超链接</a></dd>
                </dl>
            </li>

            <li class="layui-nav-item">
                <a href="javascript:;">解决方案</a>
                <dl class="layui-nav-child">
                    <dd><a href="javascript:;">列表一</a></dd>
                    <dd><a href="javascript:;">列表二</a></dd>
                    <dd><a href="">超链接</a></dd>
                </dl>
            </li>
            
            <li class="layui-nav-item"><a href="">云市场</a></li>
            <li class="layui-nav-item"><a href="">发布商品</a></li> -->
      </ul>
    </div>
</div>

<style type="text/css">
	.layui-btn{background-color: #1e9fff;}
	.layui-input{width: 400px;}
	.lyui_icon_big{font-size: 26px;color: #12a0ff;cursor: pointer;}
</style>>

<link rel="stylesheet" href="/static/css/multiple-select.css" />
<div class="layui-body" style="bottom: 0;">
    <!-- 内容主体区域 -->
    <div style="padding: 15px;">
    	<div class="layui-row">
    		<span class="layui-breadcrumb">
				<a href="/admin/index">首页</a>
			 	<!-- <a href="javascript:void(0)">广告管理</a> -->
			</span>
  		</div>
  	</div>
</div>
 		

	</div>
</body>
</html>
<script src="/static/js/jquery.min.js"></script>
<script src="/static/js/multiple-select.js"></script>
<script>
var table,form,jquery,upload,ad_path,ad_id;
var pkid = 0;
layui.use(['table','form', 'jquery','upload'], function(){
    table = layui.table;
    form = layui.form;
    jquery = layui.jquery;
    upload = layui.upload;

    jquery.ajaxSetup({
  		async: false
  	});
    //加载配置
	loadConfig();

	table.render({
	  	id : 'ad',
	    elem: '#ad',
	    height: jquery(window).height() - 185,
	    url: '/admin/ad/getListPage/',
	    limits:  <?php  echo json_encode( config('paginate.page_list'))?>,
	    limit: <?php  echo  config('paginate.list_rows')?>,
	    page: true, //开启分页,
	    loading : true,
	    cols: [[ 
	    	{field: 'ad_name', title: '名称',align:'center'},
	    	{field: 'ad_type_name', title: '类型',align:'center',templet:function(d){
				return d.ad_type == 10001001 ? '视频' : '图片';
	      	}},
	      	{field: 'ad_url', title: '外部链接地址',align:'center'},
	      	{field: 'add_time', title: '添加时间',width : 170,align:'center'},
	      	{field: 'status', title: '启用',align:'center',templet:function(d){
				var checked = d.valid_flg > 0 ? 'checked' : '';
	      		return '<input type="checkbox" value="' + d.ad_id + '" lay-filter="valid" lay-skin="switch" lay-text="ON|OFF" '+ checked +'>';
	      	}},
	      	{title:'操作',align:'center',width:120,toolbar:'#tool'}
	    ]]
  	});

	upload.render({
	    elem: '#videoUpload'
	    ,url: '/admin/base/uploadVideo/'
	    ,accept: 'file' //视频
	    ,done: function(res){
	      layer.open({
	        	content : res.msg,
	        	end:function(){
	        		if( res.status >0){
	        			ad_path = res.data.path;
	        			var preview = '<video width="320" height="240" controls>';
	        				preview += '<source src="'+ ad_path +'" type="video/mp4">';
	        				preview += '<source src="'+ ad_path +'" type="video/ogg">';
	        				preview += '<source src="'+ ad_path +'" type="video/flv">';
	        				preview += '您的浏览器不支持 HTML5 video 标签。';
	        				preview += '</video>';
	        			jquery('#preview').html(preview);
	        		}
	        	}
	        })
	    }
	  });

	//设定文件大小限制
	  upload.render({
	    elem: '#imageUpload'
	    ,url: '/admin/base/uploadImage/'
	    ,size: 1024 //限制文件大小，单位 KB
	    ,done: function(res){
	      layer.open({
	        	content : res.msg,
	        	end:function(){
	        		if( res.status >0){
	        			ad_path = res.data.path;
	        			var preview = '<img src="'+ ad_path +'" id="goods_image_dis" style="width:100px;">';
	        			jquery('#preview').html(preview);
	        		}
	        	}
	        })
	    }
	  });

  	table.on('tool(ad)', function(obj){ //注：tool是工具条事件名，test是table原始容器的属性 lay-filter="对应的值"
		var data = obj.data; //获得当前行数据
		var layEvent = obj.event; //获得 lay-event 对应的值（也可以是表头的 event 参数对应的值）
		var tr = obj.tr; //获得当前行 tr 的DOM对象
		if( layEvent == 'edit'){
			dlgAdmin(data.ad_id);
		} else if(layEvent === 'del'){ //删除
            layer.confirm('您确定要删除广告名称 ['+ data.ad_name +'] 吗？', function(index){
                del(data);
                //obj.del(); //删除对应行（tr）的DOM结构，并更新缓存
                layer.close(index);
                //向服务端发送删除指令
            });
        }
	});

	form.on('switch(valid)', function(obj){
		toggleValid(obj.value);
	})

	form.on('select(ad_type)', function(obj){
		if(obj.value == '10001001'){
			$("#videoUpload").show();
			$("#imageUpload").hide();
		} else {
			$("#videoUpload").hide();
			$("#imageUpload").show();
		}
	})
  	
});

function loadConfig(){
	var param = {};
	// param.methods = 'bank|merchant|group';
	param.methods = 'div';
	param.div_kind = 10001;
	jquery.post('/admin/ad/getPageConfig', param, function(response){
		if( response.status > 0){
			//区分
			var div = response.data.div;
			var divOpt = '<option value="0">请选择类型</option>';
			for (var i = 0; i < div.length; i++) {
				divOpt += '<option value="'+ div[i].div_id +'">' + div[i].div_name + '</option>';
			};
			$('#dlg_ad_type').html(divOpt);
			form.render();
		}
	},'JSON');
}


function search(){
	table.reload('ad',{
		where:{
			keywords : jquery('#keywords').val(),
		}
	});
}

function toggleValid(ad_id){
	var param = {};
	param.ad_id = ad_id;
	jquery.post('/admin/ad/toggleValid', param, function(response){
		if( response.status > 0){
			table.reload('ad',{});
		}
	},'JSON')
}

function dlgAdmin(ad_id){
	pkid = ad_id;
	layer.open({
	    title: '添加/编辑 广告',
	    content: jquery('#admin_action'),
	    type : 1,
	    area: ['800px', '500px'],
	    btn : ['保存'],
	    yes:function(){
	    	save();
	    },
	    success:function(){
	    	getRow(ad_id)
	    }

	});    
}

function getRow(ad_id){
	if( ad_id){
		var param ={};
		param.ad_id = ad_id
		jquery.post('/admin/ad/getRow', param, function(response){
			if( response.status > 0){
				var ad = response.data.row;
				initDlgAdmin( ad);
			}
			
		},'JSON');
	}else{
		initDlgAdmin({});
	}
}

function initDlgAdmin(ad){
	//基本信息
	jquery('#dlg_ad_name').val( ad.ad_name ? ad.ad_name : '');
	jquery('#dlg_ad_type').val( ad.ad_type ? ad.ad_type : '');
	$("#videoUpload").hide();
	$("#imageUpload").hide();

	var preview = '';
	
	// 视频
	if(ad.ad_type == 10001001){
		if(ad.ad_path){
			preview = '<video width="320" height="240" controls>';
			preview += '<source src="'+ ad.ad_path +'" type="video/mp4">';
			preview += '<source src="'+ ad.ad_path +'" type="video/ogg">';
			preview += '<source src="'+ ad.ad_path +'" type="video/flv">';
			preview += '您的浏览器不支持 HTML5 video 标签。';
			preview += '</video>';
		}
		$("#videoUpload").show();
	} else {
		if(ad.ad_path){
			preview = '<img src="'+ ad.ad_path +'" id="goods_image_dis" style="width:100px;">';
		}
		$("#imageUpload").show();
	}
	jquery('#preview').html(preview);
	jquery('#dlg_ad_url').val( ad.ad_url ? ad.ad_url : '');

	form.render('select');
}

function save(){
	var param = {};
	param.ad_id = pkid;
	param.ad_name = $.trim(jquery('#dlg_ad_name').val());
	param.ad_type = jquery('#dlg_ad_type').val();
	param.ad_path = ad_path;
	param.ad_url = $.trim(jquery('#dlg_ad_url').val());
	
	if(param.ad_name == ''){
		layer.alert("请输入广告名称");
		return;
	}

	if(param.ad_type < 1){
		layer.alert("请选择广告类型");
		return;
	}
	
	if((typeof(param.ad_path) == 'undefined' || param.ad_path == '') && param.ad_url == ''){
		layer.alert("请上传广告视频或者图片");
		return;
	}

	jquery.post('/admin/ad/save', param, function(response){
		var msg  = response.status >0 ? '操作成功' :response.msg;
		layer.open({
			content : msg,
			end:function(){
				if(response.status >0){
					table.reload('ad',{});
				layer.closeAll();
				}
			}
		});
		return false;
	},'JSON')
}

function del(data){
	var param = {};
	param.ad_id = data.ad_id;
	if(data.ad_path)
		param.ad_path = data.ad_path;
	
	jquery.post('/admin/ad/del', param, function(response){
		var msg  = response.status >0 ? '操作成功' :response.msg;
		layer.open({
			content : msg,
			end:function(){
				if(response.status >0){
					table.reload('ad',{});
				layer.closeAll();
				}
			}
		});
		return false;
	},'JSON')
}

</script>

<script type="text/html" id="tool">
	<i class="layui-icon lyui_icon_big" lay-event="edit" title="编辑">&#xe642;</i>
    <i class="layui-icon lyui_icon_big" lay-event="del" title="删除">&#xe640;</i>
	
</script>
