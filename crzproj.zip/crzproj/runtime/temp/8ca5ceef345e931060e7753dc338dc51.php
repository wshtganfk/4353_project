<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:76:"D:\xampp\htdocs\zoemp\public/../application/admin\view\admin_user\index.html";i:1561271243;s:64:"D:\xampp\htdocs\zoemp\application\admin\view\library\header.html";i:1552474293;s:62:"D:\xampp\htdocs\zoemp\application\admin\view\library\menu.html";i:1539761895;s:64:"D:\xampp\htdocs\zoemp\application\admin\view\library\footer.html";i:1531464212;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>影院广告管理</title>
    <link rel="stylesheet" href="/static/layui/css/layui.css">
    <script src="/static/js/jquery.min.js"></script>
    <script src="/static/layui/layui.js"></script>
    <script>
        var jquery,element;
        layui.use(['element', 'jquery'], function(){
            element = layui.element;
            jquery = layui.jquery;
        });

        function logout(){
            var param = {};
            jquery.post('/admin/login/doLogout', param,function(response){
                if( response.status > 0){
                    window.location.href = '/admin';
                    return true;
                }
            },'JSON')
        }
    </script>
</head>
<body class="layui-layout-body">
    <div class="layui-layout layui-layout-admin">
        <div class="layui-header">
            <div class="layui-logo">
                <img src="/static/images/nav-logo.png"/>
            </div>
            <!-- 头部区域（可配合layui已有的水平导航） -->
            <ul class="layui-nav layui-layout-right">
                <li class="layui-nav-item">
                    <a href="javascript:;">
                        <img src="http://t.cn/RCzsdCq" class="layui-nav-img">
                    <?php echo $admin['admin_name']; ?>
                    </a>
                </li>
                <li class="layui-nav-item"><a href="#" onclick="logout()">登出</a></li>
            </ul>
        </div>

<div class="layui-side layui-bg-black">
    <div class="layui-side-scroll">
        <!-- 左侧导航区域（可配合layui已有的垂直导航） -->
        <ul class="layui-nav layui-nav-tree"  lay-filter="test">
            <?php if($menu_list): foreach($menu_list as $menu): ?>
                    <li class="layui-nav-item layui-nav-itemed">
                        <a class="" href="javascript:;"><?php echo $menu['module_name']; ?></a>
                        <?php if($menu['parents'] != ""): ?>
                            <dl class="layui-nav-child">
                                <?php foreach($menu['parents'] as $childMenu): ?>
                                    <dd style="padding-left:1.2rem;" class="<?php if( stripos( $php_self, $childMenu['module_action']) !== false) echo 'layui-this'?>">
                                        <a href="<?php echo $childMenu['module_action']; ?>" ><?php echo $childMenu['module_name']; ?></a>
                                    </dd>
                                <?php endforeach; ?>
                            </dl>
                        <?php endif; ?>
                    </li>
                <?php endforeach; endif; ?>
          <!--   <li class="layui-nav-item layui-nav-itemed">
                <a class="" href="javascript:;">所有商品</a>
                <dl class="layui-nav-child">
                    <dd><a href="javascript:;">列表一</a></dd>
                    <dd><a href="javascript:;">列表二</a></dd>
                    <dd><a href="javascript:;">列表三</a></dd>
                    <dd><a href="">超链接</a></dd>
                </dl>
            </li>

            <li class="layui-nav-item">
                <a href="javascript:;">解决方案</a>
                <dl class="layui-nav-child">
                    <dd><a href="javascript:;">列表一</a></dd>
                    <dd><a href="javascript:;">列表二</a></dd>
                    <dd><a href="">超链接</a></dd>
                </dl>
            </li>
            
            <li class="layui-nav-item"><a href="">云市场</a></li>
            <li class="layui-nav-item"><a href="">发布商品</a></li> -->
      </ul>
    </div>
</div>

<style type="text/css">
    .layui-btn{background-color: #1e9fff;}
    .layui-input{width: 200px;}
    .layui-input-c{width: 400px;}
    .lyui_icon_big{font-size: 26px;color: #12a0ff;cursor: pointer;}
</style>>

<link rel="stylesheet" href="/static/css/multiple-select.css" />
<link rel="stylesheet" href="/static/css/selectmenu.css" type="text/css">
<div class="layui-body" style="bottom: 0;">
    <!-- 内容主体区域 -->
    <div style="padding: 15px;">
        <div class="layui-row">
            <span class="layui-breadcrumb">
                <a href="/admin/index">首页</a>
                <a href="javascript:void(0)">管理员列表</a>
            </span>
        </div>
        
        <div class="layui-row" style="padding-top: 15px;">
            <div class="layui-form" style="float:left;">
                <div class="layui-form-item">
                    <div class="layui-inline">
                        <label class="layui-form-label">名称：</label>
                        <div class="layui-input-block">
                          <input type="text" placeholder="管理员名称" class="layui-input" id="keywords">
                        </div>
                    </div>
                
                    <div class="layui-inline">
                        <button class="layui-btn layui-btn-normal" onclick="search()">
                        <i class="layui-icon">&#xe615;</i>
                    </button>
                    </div>
                </div>
            </div>
            <div style="float:right">
                <button class="layui-btn layui-btn-normal" style="margin-left: 25px;" onclick="dlgAdmin(0)">
                    添加
                </button>
            </div>
        </div>

        <div class="layui-row">
            <table id="adminuser" lay-filter="adminuser"></table>
        </div>

        
    </div>
</div>

<div id="form_detail" style="padding:10px;display: none;">
    <form class="layui-form "  lay-filter="user_form" id="user_form">
        <div class="layui-tab" lay-filter="test">
          <ul class="layui-tab-title">
            <li class="layui-this" lay-id="base">基本信息</li>
            <li lay-id="group">用户组/权限 信息</li>
             <li lay-id="mer">商户/门店 信息</li>
          </ul>
          <div class="layui-tab-content">
            <div class="layui-tab-item layui-show">
               <div class="layui-form-item">
                    <label class="layui-form-label">用户名：</label>
                    <div class="layui-input-block">
                        <input type="text" name="login_name" id="login_name" placeholder="请输入用户名" autocomplete="off" class="layui-input" lay-verify="required">
                    </div>
                </div> 

                <div class="layui-form-item">
                    <label class="layui-form-label">姓名：</label>
                    <div class="layui-input-block">
                        <input type="text" name="admin_name" id="admin_name" placeholder="请输入姓名"  class="layui-input" lay-verify="required">
                    </div>
                </div> 

                <div class="layui-form-item">
                    <label class="layui-form-label">密码：</label>
                    <div class="layui-input-block">
                        <input type="password" name="pwd" id="pwd" placeholder="请输入密码"  class="layui-input" lay-verify="required">
                    </div>
                </div> 

                <div class="layui-form-item">
                    <label class="layui-form-label">确认密码：</label>
                    <div class="layui-input-block">
                        <input type="password" name="confirm_pwd" id="confirm_pwd" placeholder="请再次输入密码"  class="layui-input" lay-verify="required">
                    </div>
                </div>     

                <div class="layui-form-item">
                    <label class="layui-form-label">手机：</label>
                    <div class="layui-input-block">
                        <input type="text" name="mobile" id="mobile" placeholder="请输入手机" autocomplete="off" class="layui-input" lay-verify="phone">
                    </div>
                </div>

                <div class="layui-form-item">
                    <label class="layui-form-label">邮件：</label>
                    <div class="layui-input-block">
                        <input type="text" name="email" id="email" placeholder="请输入邮件" autocomplete="off" class="layui-input" lay-verify="email">
                    </div>
                </div>

                <div class="layui-form-item">
                    <label class="layui-form-label">备注：</label>
                    <div class="layui-input-block">
                        <input type="text" name="memo" id="memo" placeholder="请输入备注" autocomplete="off" class="layui-input">
                    </div>
                </div>
            </div>
           
            <div class="layui-tab-item">
                <div class="layui-form-item">
                    <label class="layui-form-label">用户组：</label>
                    <div class="layui-input-block">
                        <input type="text" name="form_group" placeholder="请选择用户组,不选=所有" autocomplete="off" class="layui-input" onclick="dlgGroup()">
                    </div>
                </div>
            </div>   
            <div class="layui-tab-item">
               <div class="layui-form-item">
                    <label class="layui-form-label">商户：</label>
                    <div class="layui-input-block">
                        <input type="text" name="form_merchant" placeholder="请选择商户,不选=所有" autocomplete="off" class="layui-input" onclick="dlgMer()">
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">门店：</label>
                    <div class="layui-input-block">
                        <input type="text" name="form_shop" placeholder="请选择门店,不选=所有" autocomplete="off" class="layui-input" onclick="dlgShop()">
                    </div>
                </div>
                <table id="shop" lay-filter="shop"></table>
            </div>    
          </div>
        </div>
    </form>
</div>  
  

	</div>
</body>
</html>
<script src="/static/js/multiple-select.js"></script>
<script src="/static/js/selectmenu.min.js"></script> 
<script>
var table,form,jquery,upload,merchant_ids,shop_ids,group_ids,mer_id;
var g_pkid = 0;

layui.use(['table','form', 'jquery','upload'], function(){
    table = layui.table;
    form = layui.form;
    jquery = layui.jquery;
    upload = layui.upload;

    jquery.ajaxSetup({
        async: false
    });
    //加载配置
    loadConfig();

    table.render({
        id : 'adminuser',
        elem: '#adminuser',
        height: jquery(window).height() - 185,
        url: '/admin/AdminUser/getListPage/',
        limits:  <?php  echo json_encode( config('paginate.page_list'))?>,
        limit: <?php  echo  config('paginate.list_rows')?>,
        page: true, //开启分页,
        loading : true,
        cols: [[ 
            {field: 'admin_id', title: '序号',width:80,align:'center'},
            {field: 'login_name', title: '登录名称',width:160,align:'center'},
            {field: 'admin_name', title: '姓名',width:160,align:'center'},
            {field: 'mobile', title: '手机号',width:160,align:'center'},
            {field: 'last_login_ip', title: '登录IP',width:160,align:'center'},
            {field: 'last_login_time_format', title: '登录时间',width:160,align:'center'},
            {field: 'status', title: '状态',width:120,align:'center',templet:function(d){
                var checked = d.status > 0 ? 'checked' : '';
                return '<input type="checkbox" value="' + d.admin_id + '" lay-filter="valid" lay-skin="switch" lay-text="ON|OFF" '+ checked +'>';
            }},
            {title:'操作',align:'center',width:120,toolbar:'#tool'}
        ]]
    });

      //设定文件大小限制
      upload.render({
        elem: '#imageUpload'
        ,url: '/admin/base/uploadImage/?dir=logo'
        ,size: 1024 //限制文件大小，单位 KB
        ,done: function(res){
          layer.open({
                content : res.msg,
                end:function(){
                    if( res.status >0){
                        img_path = res.data.path;
                        $('#logo_img').attr('src', img_path);
                    }
                }
            })
        }
      });

    table.on('tool(adminuser)', function(obj){ //注：tool是工具条事件名，test是table原始容器的属性 lay-filter="对应的值"
        var data = obj.data; //获得当前行数据
        var layEvent = obj.event; //获得 lay-event 对应的值（也可以是表头的 event 参数对应的值）
        var tr = obj.tr; //获得当前行 tr 的DOM对象
        if( layEvent == 'edit'){
            dlgAdmin(data);
        } else if(layEvent === 'del'){ //删除
            layer.confirm('您确定要删除广告名称 ['+ data.mer_name +'] 吗？', function(index){
                del(data);
                //obj.del(); //删除对应行（tr）的DOM结构，并更新缓存
                layer.close(index);
                //向服务端发送删除指令
            });
        }
    });

    form.on('switch(valid)', function(obj){
        toggleValid(obj.value);
    }) 

    form.on('checkbox(chkAll)', function(obj){
        //这里实现勾选 
        $('.form_modules input[name=module]').each(function(index, item){
            item.checked = obj.elem.checked;
        });
        form.render('checkbox');

        //当前元素
        //var data = $(obj.elem);
        //遍历父级tr，取第一个，然后查找第二个td，取值
        //var id = data.parents('tr').first().find('td').eq(1).text();
        //var check = obj.elem.checked;
    });   
});

function loadConfig(){
    var param = {};
    // param.methods = 'bank|merchant|group';
    param.methods = 'div';
    param.div_kind = 10001;
    $.post('/admin/base/getPageConfig', param, function(response){
        // if( response.status > 0){
        //     //区分
        //     var div = response.data.div;
        //     var divOpt = '<option value="0">请选择类型</option>';
        //     for (var i = 0; i < div.length; i++) {
        //         divOpt += '<option value="'+ div[i].div_id +'">' + div[i].div_name + '</option>';
        //     };
        //     $('#dlg_ad_type').html(divOpt);
        //     form.render();
        // }
    },'JSON');
}


function search(){
    table.reload('adminuser',{
        where:{
            keywords : jquery('#keywords').val(),
        }
    });
}

function toggleValid(pkid){
    var param = {};
    param.admin_id = pkid;
    param.field = 'status';
    $.post('/admin/AdminUser/toggleValid', param, function(response){
        if( response.status > 0){
            table.reload('adminuser',{});
        }
    },'JSON')
}

function dlgAdmin(data){
    var pkid = 0;
    if(data) pkid = data.admin_id
    layer.open({
        title: '添加/编辑 管理员',
        content: jquery('#form_detail'),
        type : 1,
        area: ['900px', '550px'],
        btn : ['保存','关闭'],
        yes:function(){
            save(pkid);
        },
        btn2:function(){
            
        },
        success:function(index){
            if(!data) data = {};
            initDlgAdmin(data)
        }

    });    
}

function getRow(pkid){
    pkid = pkid
    if( pkid){
        var param ={};
        param.mer_id = pkid
        $.post('/admin/AdminUser/getRow', param, function(response){
            if( response.status > 0){
                var row = response.data.row;
                initDlgAdmin( row);
            }
            
        },'JSON');
    }else{
        initDlgAdmin({});
    }
}

var selectGroup = [];
var selectMerchant = [];
var selectShop = [];
function initDlgAdmin(data){
    //基本信息
    $('#login_name').val( data.login_name ? data.login_name : '');
    $('#admin_name').val( data.admin_name ? data.admin_name : '');
    $('#mobile').val( data.mobile ? data.mobile : '');
    $('#email').val( data.email ? data.email : '');
    $('#memo').val( data.memo ? data.memo : '');

    /* 管理员组 */
    selectGroup = data.group_list;
    if( selectGroup ){
        var tempGroupids = [],tempGroupNames = [],groupNames;
        for (var i = 0; i < selectGroup.length; i++) {
            tempGroupids.push(selectGroup[i].group_id);
            tempGroupNames.push(selectGroup[i].group_name);
        }
        group_ids = tempGroupids.join(',');
        groupNames = tempGroupNames.join(',');
        $('input[name=form_group]').val(groupNames);
    }

    /* 商户 */
    selectMerchant = data.mer_list;
    if( selectMerchant ){
        var tempMerids = [],tempMerNames = [],merNames;
        for (var i = 0; i < selectMerchant.length; i++) {
            tempMerids.push(selectMerchant[i].mer_id);
            tempMerNames.push(selectMerchant[i].mer_name);
        }
        merchant_ids = tempMerids.join(',');
        merNames = tempMerNames.join(',');
        $('input[name=form_merchant]').val(merNames);
    }

    /* 门店 */
    selectShop = data.shop_list;
    if( selectShop ){
        var tempShopids = [],tempShopNames = [],shopNames;
        for (var i = 0; i < selectShop.length; i++) {
            tempShopids.push(selectShop[i].shop_id);
            tempShopNames.push(selectShop[i].shop_name);
        }
        shop_ids = tempShopids.join(',');
        shopNames = tempShopNames.join(',');
        $('input[name=form_shop]').val(shopNames);
    }
    form.render('select');
}

function save(pkid){
    var param = {};
    param.admin_id = pkid;
    param.merchant_ids = merchant_ids;
    param.shop_ids = shop_ids;
    param.group_ids = group_ids;
    param.login_name = $.trim($('#login_name').val());
    param.admin_name = $.trim($('#admin_name').val());
    param.pwd = $.trim($('#pwd').val());
    param.confirm_pwd = $.trim($('#confirm_pwd').val());
    param.mobile = $.trim($('#mobile').val());
    param.email = $.trim($('#email').val());
    param.memo = $.trim($('#memo').val());
    
    if(param.login_name == ''){
        layer.alert("请输入用户名");
        return;
    }

    if(param.admin_name == ''){
        layer.alert("请输入姓名");
        return;
    }
    if(pkid == 0){
        if(param.pwd == ''){
            layer.alert("请输入密码");
            return;
        }

        if(param.pwd.length < 6){
            layer.alert("密码长度不能低于6位");
            return;
        }

        if(param.confirm_pwd == ''){
            layer.alert("请再次输入密码");
            return;
        }

        if(param.pwd != param.confirm_pwd){
            layer.alert("两次输入的密码不一致");
            return;
        }
    }

    $.post('/admin/AdminUser/save', param, function(response){
        var msg  = response.status >0 ? '操作成功' :response.msg;
        layer.open({
            content : msg,
            end:function(){
                if(response.status >0){
                    table.reload('adminuser',{});
                layer.closeAll();
                }
            }
        });
        return false;
    },'JSON')
}

function del(data){
    var param = {};
    param.ad_id = data.ad_id;
    if(data.ad_path)
        param.ad_path = data.ad_path;
    
    $.post('/admin/AdminUser/del', param, function(response){
        var msg  = response.status >0 ? '操作成功' :response.msg;
        layer.open({
            content : msg,
            end:function(){
                if(response.status >0){
                    table.reload('ad',{});
                layer.closeAll();
                }
            }
        });
        return false;
    },'JSON')
}

function dlgGroup(){
    $.post('/admin/group/groupList',{},function(response){
        if( response.status > 0 ){
            var group_list = response.data.group_list;
            //初始化插件
            $('input[name=form_group]').selectMenu({
                showField : 'group_name',
                keyField : 'group_id',
                searchField : 'group_name',
                data : group_list,
                multiple:true,
                title : '请选择用户组',
                eSelect:function(data){
                    var groupNames = '';
                    var groupIds = '';
                    $('.sm_results li.sm_selected').each(function(){

                        groupIds += $(this).attr('pkey') + ',';
                        groupNames += $(this).attr('title') + ',';
                    });
                    groupNames = groupNames.substring(0, groupNames.length - 1);
                    group_ids = groupIds.substring(0, groupIds.length - 1);
                    $('input[name=form_group]').val(groupNames);                           

                }

            });
            $('.sm_container').css('z-index',999999999);
            $('.sm_results li').each(function(){
                var pkey = $(this).attr('pkey');
                for (var i = 0; i < selectGroup.length; i++) {
                    if( selectGroup[i].group_id  == pkey){
                        $(this).addClass('sm_selected');
                    }
                }
            })
        }
    },'JSON')
}

function dlgMer(){
    $.post('/admin/merchant/merchantList',{},function(response){
        if( response.status > 0 ){
            var merchants = response.data.merchants;
            //初始化插件
            $('input[name=form_merchant]').selectMenu({
                showField : 'mer_name',
                keyField : 'mer_id',
                searchField : 'mer_name',
                data : merchants,
                multiple:true,
                title : '请选择商户',
                eSelect:function(data){
                    var merNames = '';
                    var merIds = '';
                    $('.sm_results li.sm_selected').each(function(){
                        merIds += $(this).attr('pkey') + ',';
                        merNames += $(this).attr('title') + ',';
                    });
                    merNames = merNames.substring(0, merNames.length - 1);
                    merchant_ids = merIds.substring(0, merIds.length - 1);
                    $('input[name=form_merchant]').val(merNames);                           
                }

            });
            $('.sm_container').css('z-index',999999999);
            $('.sm_results li').each(function(){
                var pkey = $(this).attr('pkey');
                for (var i = 0; i < selectMerchant.length; i++) {
                    if( selectMerchant[i].mer_id  == pkey){
                        $(this).addClass('sm_selected');
                    }
                }
            })
        }
    },'JSON');
}

function dlgShop(){
    $('input[name=form_shop]').selectMenu({
        showField : 'shop_name',
        keyField : 'shop_id',
        searchField : 'shop_name',
        data:function(){
            var param = {};
            param.mer_ids = merchant_ids;
            var data = [];
            $.post('/admin/cinema/cinemaList',param,function(response){
                if( response.status > 0 ){
                    var shop_list = response.data.shop_list;
                    for (var i = 0; i < shop_list.length; i++) {
                        data.push(shop_list[i]);
                    }
                    //初始化插件
                }
            },'JSON');
            return data;
        },
        multiple:true,
        title : '请选择门店',
        eSelect:function(data){
            var shopNames = '';
            var shopIds = '';
            $('.sm_results li.sm_selected').each(function(){
                shopIds += $(this).attr('pkey') + ',';
                shopNames += $(this).attr('title') + ',';
            });
            shopNames = shopNames.substring(0, shopNames.length - 1);
            shop_ids = shopIds.substring(0, shopIds.length - 1);
            $('input[name=form_shop]').val(shopNames);                           
        }

    });
    $('.sm_container').css('z-index',999999999);
    $('.sm_results li').each(function(index, el) {
        var pkey = $(this).attr('pkey');        
        for (var i = 0; i < selectShop.length; i++) {
            if(selectShop[i].shop_id == pkey){
                $(this).addClass('sm_selected');
            }
        }
    });
}


</script>

<script type="text/html" id="tool">
    <i class="layui-icon lyui_icon_big" lay-event="edit" title="编辑">&#xe642;</i>
    <!-- <i class="layui-icon lyui_icon_big" lay-event="del" title="删除">&#xe640;</i> -->
</script>

<!--format modules-->
<script type="text/javascript" id="template_modules">
    {{# for(var i = 0;i<d.modules.length;i++){ }}
       {{ d.modules[i].module_name}}
    {{# } }} 
</script>
