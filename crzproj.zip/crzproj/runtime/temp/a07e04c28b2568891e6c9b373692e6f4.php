<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:76:"D:\xampp\htdocs\crzproj\public/../application/index\view\register\index.html";i:1587573672;}*/ ?>
<!DOCTYPE htm>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>registration Form</title>
        <link rel ="stylesheet" href="/static/css/register.css">
        <link rel="stylesheet" href="/static/layui/css/layui.css">
    </head>
    <body>
        <form class="LG" action="" method="post">
            <h1>register</h1>
            Enter your Username : <input type="text" name="username" id="username" autocomplete="true" placeholder="Username">
            Enter your Password : <input type="password" name="password" id="password" autocomplete="true" placeholder="Password">
            Enter your Email address: <input type="email" name="email" id="email" autocomplete="true" placeholder="Email Address">
            <input type="button" name="btnRegister" id="btnRegister" value="submit">
            <a href="login.html">Already have account? </a>
        </form>
        <script src="/static/js/jquery.min.js"></script>
        <script src="/static/layui/layui.js"></script>
        <script type="text/javascript">
            layui.use('form',function(){
                var form = layui.form;
            });
             $('#btnRegister').on('click',()=>{
                var username = $.trim($('#username').val());
                var password = $.trim($('#password').val());
                var email = $.trim($('#email').val());
                if(username == '') {
                    layer.alert('please enter username'); 
                    $('#username').focus();
                    return false;
                }
                if(password == '') {
                    layer.alert('please enter password'); 
                    $('#password').focus();
                    return false;
                }
                if(email == '') {
                    layer.alert('please enter email address'); 
                    $('#email').focus();
                    return false;
                }
                var reg = /^([a-zA-Z]|[0-9])(\w|\-)+@[a-zA-Z0-9]+\.([a-zA-Z]{2,4})$/;
                if(!reg.test(email)){
                    layer.alert('please enter correct email address'); 
                    $('#email').focus();
                    return false;
                }
                var fd = {};
                fd.username = username;
                fd.password = password;
                fd.email = email;
                $.post('/index/index/doRegister', fd, function(res){
                if(res.code > 0){
                    layer.alert(res.msg);    
                    return false;
                }else{
                    window.location.href = '/index/index/manage';
                    return true;
                }
            },'JSON')
             })
        </script>
    </body>
</html>

