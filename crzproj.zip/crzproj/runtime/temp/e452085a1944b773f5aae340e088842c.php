<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:72:"D:\xampp\htdocs\crzproj\public/../application/index\view\main\index.html";i:1587638383;}*/ ?>
<!DOCTYPE htm>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>Animated Login </title>
        <link rel ="stylesheet" href="/static/css/main.css">
        <link rel="stylesheet" href="/static/layui/css/layui.css">
    </head>
    <body>
        <div class="wrapper">
            <h1>MAIN MENU</h1>
            <div class="content">
                <p>
                    <a href="manage.html">profile management</a>
                </p>
                <p>
                    <a href="fuelQf.html">fuel quote form</a>
                </p>
                <p>
                    <a href="fuelQh.html">fule quote history</a>
                </p>
            </div>
            <p>
                <input type="button" id="btnLogOut" name="btnLogOut" value="Logout">
            </p>
        </div>
     <script src="/static/js/jquery.min.js"></script>
     <script src="/static/layui/layui.js"></script>
     <script type="text/javascript">
        layui.use('form',function(){
            var form = layui.form;
        });
        $('#btnLogOut').on('click',()=>{
            window.location.href = '/index/index/logOut';
            return true;
        })
     </script>
    </body>
</html>
