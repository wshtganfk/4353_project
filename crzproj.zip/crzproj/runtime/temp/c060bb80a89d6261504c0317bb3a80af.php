<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:71:"D:\xampp\htdocs\zoemp\public/../application/admin\view\login\index.html";i:1544000085;}*/ ?>
<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- 上述3个meta标签*必须*放在最前面，任何其他内容都*必须*跟随其后！ -->
    <title></title>

    <!-- Bootstrap -->
    <link href="/static/css/bootstrap.min.css" rel="stylesheet">
    <link href="/static/css/common.css" rel="stylesheet">
    <link rel="stylesheet" href="/static/layui/css/layui.css">
    <link href="/static/css/login.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 8]>
      <script src="https://cdn.bootcss.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
.wrapper{background: transparent;}

    </style>
  </head>
  <body>
    <nav class="navbar navbar-inverse navbar-fixed-top com-bg">
      <div class="container wpapper">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">
            <img src="/static//images/nav-logo.png" alt="">
          </a>
        </div>
      </div>
    </nav>
    <div class="wrapper clearfix clearfix">
      <div class="action fl">
        <img src="/static/images/login.png" alt="">
      </div>
      <div class="fl main layui-form">
          <h1>登 录</h1>
          <input type="text" placeholder="请输入用户名" id="login_name">
          <input type="password" placeholder="请输入密码" id="password">
          <div class="clearfix">
                <input type="text" class="fl verification-text" placeholder="请输入验证码" id="captcha" onkeyup="if(event.keyCode == 13) login()">
                <div class="fl  verification">
                <img width="100%" src="/captcha" alt="captcha" onclick="this.src='/captcha'" id="captchaImg"/></div>
          </div>
          <div>
            <div class="layui-form-item clearfix" pane="" style="display:inline-block">
              <div class="layui-input-block fl">
                <input type="checkbox" name="" lay-skin="primary"  checked="">
              </div>
              <label class="layui-form-label fl">下次自动登录</label>
            </div>
            <a href=""style="display:inline-block" class="forget">忘记密码？</a>
          </div>
        <button class="layui-btn layui-btn-normal" onclick="login()">登  录</button>
      </div>

    <script src="/static/js/jquery.min.js"></script>
    <script src="/static/js/common.js"></script>
    <script src="/static/layui/layui.js"></script>


<script>
    layui.use('form',function(){
        var form = layui.form;
    });


    function login(){ 
        var param = {};
        param.login_name = $('#login_name').val();
        param.password = $('#password').val();
        param.captcha = $('#captcha').val();
        $.post('/admin/login/doLogin', param, function(response){
            if(response.status > 0){
                window.location.href = '/admin/index/index';
                return false;
            }else{
                 $('#captchaImg').click();
                layer.alert(response.msg);    
            }
        },'JSON')
    }

</script>
  </body>
</html>