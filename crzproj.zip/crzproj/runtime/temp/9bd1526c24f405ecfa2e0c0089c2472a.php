<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"D:\xampp\htdocs\crzproj\public/../application/index\view\manage\index.html";i:1587613097;}*/ ?>
<!DOCTYPE htm>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>File management</title>
        <link rel ="stylesheet" href="/static/css/File_manage.css">
        <link rel="stylesheet" href="/static/layui/css/layui.css">
    </head>
    <body>
        <form class="LG" action="login.html" method="post">
        <h1>Profile management</h1>
        Enter your Fullname : <input type="text" id="fullname" name="fullname" value="<?php echo $fullname; ?>" placeholder="Fullname">
        Enter your Address 1 : <input type="text" id="address1" name="address1" value="<?php echo $address1; ?>" placeholder="Address 1">
        Enter your Address 2 : <input type="text" id="address2" name="address2" value="<?php echo $address2; ?>" placeholder="Address 2">
        Enter your City : <input type="text" id="city" name="city" value="<?php echo $city; ?>" placeholder="City">
        Enter your State : <select name="state" id="state">
            <?php if(is_array($states) || $states instanceof \think\Collection || $states instanceof \think\Paginator): $i = 0; $__LIST__ = $states;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
            <option value="<?php echo $vo; ?>" <?php if($state == $vo): ?>selected<?php endif; ?>><?php echo $vo; ?></option>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </select>
        
    <p> Enter your Zipcode: <input type="text" id="zipcode" name="zipcode" value="<?php echo $zipcode; ?>" placeholder="Zipcode"></p> 
        <input type="button" id="btnOk" name="btnOk" value="submit">
    
        </form>
    <script src="/static/js/jquery.min.js"></script>
        <script src="/static/layui/layui.js"></script>
        <script type="text/javascript">
            layui.use('form',function(){
                var form = layui.form;
            });
             $('#btnOk').on('click',()=>{
                var fullname = $.trim($('#fullname').val());
                var address1 = $.trim($('#address1').val());
                var address2 = $.trim($('#address2').val());
                var city = $.trim($('#city').val());
                var state = $.trim($('#state').val());
                var zipcode = $.trim($('#zipcode').val());
                if(fullname == '') {
                    layer.alert('please enter fullname'); 
                    $('#fullname').focus();
                    return false;
                }
                var fd = {};
                fd.fullname = fullname;
                fd.address1 = address1;
                fd.address2 = address2;
                fd.city = city;
                fd.state = state;
                fd.zipcode = zipcode;
                $.post('/index/index/doManage', fd, function(res){
                if(res.code > 0){
                    // layer.alert(res.msg);  
                    window.location.href = '/index/index/fuelQf';  
                    return false;
                }else{
                    // layer.alert(res.msg);
                    window.location.href = '/index/index/fuelQf';
                    return true;
                }
            },'JSON')
             })
        </script>
    </body>
</html>

