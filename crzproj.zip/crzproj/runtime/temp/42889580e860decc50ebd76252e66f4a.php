<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:72:"D:\xampp\htdocs\zoemp\public/../application/admin\view\cinema\index.html";i:1572500336;s:64:"D:\xampp\htdocs\zoemp\application\admin\view\library\header.html";i:1552474293;s:62:"D:\xampp\htdocs\zoemp\application\admin\view\library\menu.html";i:1539761895;s:64:"D:\xampp\htdocs\zoemp\application\admin\view\library\footer.html";i:1531464212;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>影院广告管理</title>
    <link rel="stylesheet" href="/static/layui/css/layui.css">
    <script src="/static/js/jquery.min.js"></script>
    <script src="/static/layui/layui.js"></script>
    <script>
        var jquery,element;
        layui.use(['element', 'jquery'], function(){
            element = layui.element;
            jquery = layui.jquery;
        });

        function logout(){
            var param = {};
            jquery.post('/admin/login/doLogout', param,function(response){
                if( response.status > 0){
                    window.location.href = '/admin';
                    return true;
                }
            },'JSON')
        }
    </script>
</head>
<body class="layui-layout-body">
    <div class="layui-layout layui-layout-admin">
        <div class="layui-header">
            <div class="layui-logo">
                <img src="/static/images/nav-logo.png"/>
            </div>
            <!-- 头部区域（可配合layui已有的水平导航） -->
            <ul class="layui-nav layui-layout-right">
                <li class="layui-nav-item">
                    <a href="javascript:;">
                        <img src="http://t.cn/RCzsdCq" class="layui-nav-img">
                    <?php echo $admin['admin_name']; ?>
                    </a>
                </li>
                <li class="layui-nav-item"><a href="#" onclick="logout()">登出</a></li>
            </ul>
        </div>

<div class="layui-side layui-bg-black">
    <div class="layui-side-scroll">
        <!-- 左侧导航区域（可配合layui已有的垂直导航） -->
        <ul class="layui-nav layui-nav-tree"  lay-filter="test">
            <?php if($menu_list): foreach($menu_list as $menu): ?>
                    <li class="layui-nav-item layui-nav-itemed">
                        <a class="" href="javascript:;"><?php echo $menu['module_name']; ?></a>
                        <?php if($menu['parents'] != ""): ?>
                            <dl class="layui-nav-child">
                                <?php foreach($menu['parents'] as $childMenu): ?>
                                    <dd style="padding-left:1.2rem;" class="<?php if( stripos( $php_self, $childMenu['module_action']) !== false) echo 'layui-this'?>">
                                        <a href="<?php echo $childMenu['module_action']; ?>" ><?php echo $childMenu['module_name']; ?></a>
                                    </dd>
                                <?php endforeach; ?>
                            </dl>
                        <?php endif; ?>
                    </li>
                <?php endforeach; endif; ?>
          <!--   <li class="layui-nav-item layui-nav-itemed">
                <a class="" href="javascript:;">所有商品</a>
                <dl class="layui-nav-child">
                    <dd><a href="javascript:;">列表一</a></dd>
                    <dd><a href="javascript:;">列表二</a></dd>
                    <dd><a href="javascript:;">列表三</a></dd>
                    <dd><a href="">超链接</a></dd>
                </dl>
            </li>

            <li class="layui-nav-item">
                <a href="javascript:;">解决方案</a>
                <dl class="layui-nav-child">
                    <dd><a href="javascript:;">列表一</a></dd>
                    <dd><a href="javascript:;">列表二</a></dd>
                    <dd><a href="">超链接</a></dd>
                </dl>
            </li>
            
            <li class="layui-nav-item"><a href="">云市场</a></li>
            <li class="layui-nav-item"><a href="">发布商品</a></li> -->
      </ul>
    </div>
</div>

<style type="text/css">
    .layui-btn{background-color: #1e9fff;}    
    .layui-input-c{width: 400px;}
    .lyui_icon_big{font-size: 26px;color: #12a0ff;cursor: pointer;}
</style>>

<link rel="stylesheet" href="/static/css/multiple-select.css" />
<div class="layui-body" style="bottom: 0;">
    <!-- 内容主体区域 -->
    <div style="padding: 15px;">
        <div class="layui-row">
            <span class="layui-breadcrumb">
                <a href="/admin/index">首页</a>
                <a href="javascript:void(0)">影院列表</a>
            </span>
        </div>
        
        <div class="layui-row" style="padding-top: 15px;">
            <div class="layui-form" style="float:left;">
                <div class="layui-form-item">
                    <div class="layui-inline">
                        <label class="layui-form-label">名称：</label>
                        <div class="layui-input-block">
                          <input type="text" placeholder="影院名称|简称"  class="layui-input" id="keywords">
                        </div>
                    </div>
                
                    <div class="layui-inline">
                        <button class="layui-btn layui-btn-normal" onclick="search()">
                        <i class="layui-icon">&#xe615;</i>
                    </button>
                    </div>
                </div>
            </div>
            <div style="float:right">
                <button class="layui-btn layui-btn-normal" style="margin-left: 25px;" onclick="getMerDlg(0)">
                    获取影院
                </button>
            </div>
        </div>

        <div class="layui-row">
            <table id="tableList" lay-filter="tableList"></table>
        </div>

        
    </div>
</div>

<div id="form_mer" style="display: none;">
    <form class="layui-form" action="">
        <div style="margin: 15px 15px 0 0">
            <div class="layui-form-item">
                <label class="layui-form-label">商户</label>
                <div class="layui-input-block">
                     <select id="dlg_mer_list" lay-filter="mer_list"></select>
                </div>
            </div>
        </div>  
    </form>
</div>

<div id="form_detail" style="display: none;">
<form class="layui-form" action="">
    <div style="margin-top:15px;margin-left:15px;">
        <div class="layui-form-item">
            <div class="layui-block">
                <label class="layui-form-label">影院名称：</label>
                <div class="layui-input-block">
                  <input type="text" placeholder="请输入影院名称"  class="layui-input layui-input-c" id="shop_name">
                </div>
            </div>
        </div>
        <div class="layui-form-item">
            <div class="layui-block">
                <label class="layui-form-label">影院简称：</label>
                <div class="layui-input-block">
                  <input type="text" placeholder="请输入影院简称"  class="layui-input layui-input-c" id="shop_arv">
                </div>
            </div>
        </div>

        <div class="layui-form-item">
            <label class="layui-form-label">区域</label>
            <div class="layui-input-inline">
                <select id="province" lay-search lay-filter="province"></select>
            </div>
            <div class="layui-input-inline">
                <select id="city" lay-search lay-filter="city"></select>
            </div>
            <div class="layui-input-inline">
                <select id="district" lay-search></select>
            </div>
        </div>

        <div class="layui-form-item">
                <label class="layui-form-label">影院地址：</label>
                <div class="layui-input-block">
                  <input type="text" id="shop_address" placeholder="请输入影院地址" class="layui-input">
                </div>
            </div>
        <div class="layui-form-item">
            <div class="layui-block">
                <label class="layui-form-label">票版编号：</label>
                <div class="layui-input-block">
                  <input type="number" placeholder="请输入票版编号"  class="layui-input layui-input-c" id="ticket_no">
                </div>
            </div>
        </div>
        <div class="layui-form-item">
            <div class="layui-block">
                <label class="layui-form-label">入场间隔：</label>
                <div class="layui-input-block">
                  <input type="text" 
                         placeholder="提前多长时间入场"  
                         class="layui-input layui-input-c"
                         id="enter_interval">
                </div>
            </div>
        </div>
        
        <div class="layui-form-item">
            <label class="layui-form-label">转赠：</label>
            <div class="layui-input-block">
              <input type="radio" name="is_give" id="is_give" value="1" title="是">
              <input type="radio" name="is_give" id="is_give" value="0" title="否" checked>
            </div>
        </div>
    </form>
</div>
  

	</div>
</body>
</html>
<script src="/static/js/jquery.min.js"></script>
<script src="/static/js/multiple-select.js"></script>
<script>
var table,form,jquery,upload,img_path,mer_id;
var g_pkid = 0;
layui.use(['table','form', 'jquery','upload'], function(){
    table = layui.table;
    form = layui.form;
    jquery = layui.jquery;
    upload = layui.upload;

    jquery.ajaxSetup({
        async: false
    });
    //加载配置
    loadConfig();

    table.render({
        id : 'tableList',
        elem: '#tableList',
        height: jquery(window).height() - 185,
        url: '/admin/cinema/getListPage/',
        limits:  <?php  echo json_encode( config('paginate.page_list'))?>,
        limit: <?php  echo  config('paginate.list_rows')?>,
        page: true, //开启分页,
        loading : true,
        cols: [[ 
            {field: 'shop_id', title: '序号',width:80,align:'center'},
            {field: 'mer_name', title: '商户名称',align:'center'},
            {field: 'shop_name', title: '影院名称',width : 170,align:'center'},
            {field: 'shop_name', title: '影院简称',width : 170,align:'center'},
            {field: 'api_shop_no', title: '影院编码',align:'center'},
            {field: 'zz_cinema_code', title: '专资编码',align:'center'},
            {field: 'enter_interval', title: '入场间隔',edit:'text',align:'center'},
            {field: 'status', title: '转赠',align:'center',templet:function(d){
                var checked = d.is_give > 0 ? 'checked' : '';
                return '<input type="checkbox" value="' + d.shop_id + '" lay-filter="is_give" lay-skin="switch" lay-text="ON|OFF" '+ checked +'>';
            }},
            {field: 'status', title: '状态',align:'center',templet:function(d){
                var checked = d.valid_flg > 0 ? 'checked' : '';
                return '<input type="checkbox" value="' + d.shop_id + '" lay-filter="valid" lay-skin="switch" lay-text="ON|OFF" '+ checked +'>';
            }},
            {title:'操作',align:'center',width:60,toolbar:'#tool'}
        ]]
    });

      //设定文件大小限制
      upload.render({
        elem: '#imageUpload'
        ,url: '/admin/base/uploadImage/?dir=logo'
        ,size: 1024 //限制文件大小，单位 KB
        ,done: function(res){
          layer.open({
                content : res.msg,
                end:function(){
                    if( res.status >0){
                        img_path = res.data.path;
                        $('#logo_img').attr('src', img_path);
                    }
                }
            })
        }
      });

    table.on('tool(tableList)', function(obj){ //注：tool是工具条事件名，test是table原始容器的属性 lay-filter="对应的值"
        var data = obj.data; //获得当前行数据
        var layEvent = obj.event; //获得 lay-event 对应的值（也可以是表头的 event 参数对应的值）
        var tr = obj.tr; //获得当前行 tr 的DOM对象
        if( layEvent == 'edit'){
            dlgAdmin(data.shop_id);
        } else if(layEvent === 'del'){ //删除
            layer.confirm('您确定要删除广告名称 ['+ data.mer_name +'] 吗？', function(index){
                del(data);
                //obj.del(); //删除对应行（tr）的DOM结构，并更新缓存
                layer.close(index);
                //向服务端发送删除指令
            });
        }
    });

    table.on('edit(tableList)',function(obj){
        /* 得到修改后的值 */
        var val = obj.value;
        /* 得到所在行所有键值 */
        var data = obj.data;
        /* 得到要编辑的字段 */
        var field = obj.field;
        layer.msg('field='+data.shop_id);

        updateCol(data.shop_id,field,val);
    });

    form.on('switch(is_give)', function(obj){
        toggleValid(obj.value,'is_give');
    })

    form.on('switch(valid)', function(obj){
        toggleValid(obj.value,'valid_flg');
    })

    form.on('select(province)', function(data){
        getRegions('city',data.value);        
    });   

    form.on('select(city)', function(data){
        getRegions('district',data.value);
    });
    
});

function getRegions(ctrl,region_id){
    var param = {};
    param.region_id = region_id;

    $.post('/admin/base/getRegions', param, function(response){
        if( response.status > 0){
            var resData = response.data;
            var opt = '<option value="0">请选择区域</option>';
            for (var i = 0; i < resData.length; i++) {
                opt += '<option value="'+ resData[i].region_id +'">' + resData[i].region_name + '</option>';
            };

            $('#'+ctrl).html(opt);
            form.render();
        }
    },'JSON');

}

function loadConfig(){
    var param = {};
    // param.methods = 'bank|merchant|group';
    param.methods = 'merchant';
    // param.div_kind = 10001;
    jquery.post('/admin/base/getPageConfig', param, function(response){
        if( response.status > 0){
            var resData = response.data.merchant;
            var opt = '<option value="0">请选择商户</option>';
            for (var i = 0; i < resData.length; i++) {
                opt += '<option value="'+ resData[i].mer_id +'">' + resData[i].mer_arv + '</option>';
            };
            $('#dlg_mer_list').html(opt);
            form.render();
        }
    },'JSON');

    getRegions('province',1);
}


function search(){
    table.reload('tableList',{
        where:{
            keywords : jquery('#keywords').val(),
        }
    });
}

function updateCol(pkid,field,val){
    var param = {};
    param.shop_id = pkid;
    param.field = field;
    param.val = val;

    $.post('/admin/cinema/updateCol',param,function(response){
        if( response.status > 0){
            layer.msg(response.msg);
            //table.reload('tableList',{});
        } else {
            layer.msg(response.msg);
        }
    },'JSON')
}

function toggleValid(pkid,field){
    var param = {};
    param.shop_id = pkid;
    param.field = field;
    $.post('/admin/cinema/toggleValid', param, function(response){
        if( response.status > 0){
            table.reload('tableList',{});
        }
    },'JSON')
}

function getMerDlg(){
    layer.open({
        title: '获取影院列表',
        content: jquery('#form_mer'),
        type : 1,
        shadeClose:true,
        area: ['350px', '400px'],
        btn : ['获取'],
        yes:function(){
            getCinema();
        },
        btn2:function(){
            
        },
        success:function(index){
            // getRow(pkid)
        }

    });
}

function getCinema(){
    var param = {};
    var mer_id = $("#dlg_mer_list").val();
    if(mer_id == 0){
        layer.alert("请选择商户");
        return;
    }
    param.mer_id = mer_id;

    $.post('/admin/cinema/getCinemas', param, function(response){
        var msg  = response.status >0 ? '操作成功' :response.msg;
        layer.open({
            content : msg,
            end:function(){
                if(response.status >0){
                    table.reload('tableList',{});
                layer.closeAll();
                }
            }
        });
        return false;
    },'JSON')
}

function dlgAdmin(pkid){
    layer.open({
        title: '添加/编辑 影院',
        content: jquery('#form_detail'),
        type : 1,
        area: ['900px', '500px'],
        btn : ['保存','关闭'],
        yes:function(){
            save(pkid);
        },
        btn2:function(){
            
        },
        success:function(index){
            getRow(pkid)
        }

    });    
}

function getRow(pkid){
    if( pkid){
        var param ={};
        param.shop_id = pkid
        $.post('/admin/cinema/getRow', param, function(response){
            if( response.status > 0){
                var row = response.data.row;
                initDlgAdmin( row);
            }
            
        },'JSON');
    }else{
        initDlgAdmin({});
    }
}

function initDlgAdmin(frm){
    //基本信息
    $('#shop_name').val( frm.shop_name ? frm.shop_name : '');
    $('#shop_arv').val( frm.shop_arv ? frm.shop_arv : '');
    $('#ticket_no').val( frm.ticket_no ? frm.ticket_no : '');
    $('#enter_interval').val( frm.enter_interval ? frm.enter_interval : '');
    $('#shop_address').val( frm.address ? frm.  address : '');

    getRegions('city', frm.province_id);
    getRegions('district', frm.city_id);

    $('#province option[value="'+ frm.province_id +'"]').attr('selected', true);
    $('#city option[value="'+ frm.city_id +'"]').attr('selected', true);
    $('#district option[value="'+ frm.district_id +'"]').attr('selected', true);
    form.render();
    //form.render('select');
}

function save(pkid){
    var param = {};
    param.shop_id = pkid;
    param.shop_name = $.trim($('#shop_name').val());
    param.shop_arv = $.trim($('#shop_arv').val());
    param.province_id = $.trim($('#province').val());
    param.city_id = $.trim($('#city').val());
    param.district_id = $.trim($('#district').val());
    param.address = $.trim($('#shop_address').val());
    param.ticket_no = parseInt($.trim($('#ticket_no').val()));
    param.is_give = $.trim($('#is_give').val());
    param.enter_interval = $.trim($('#enter_interval').val());
    
    $.post('/admin/cinema/save', param, function(response){
        var msg  = response.status >0 ? '操作成功' :response.msg;
        layer.open({
            content : msg,
            end:function(){
                if(response.status >0){
                    table.reload('tableList',{});
                layer.closeAll();
                }
            }
        });
        return false;
    },'JSON')
}

function del(data){
    var param = {};
    param.ad_id = data.ad_id;
    if(data.ad_path)
        param.ad_path = data.ad_path;
    
    $.post('/admin/cinema/del', param, function(response){
        var msg  = response.status >0 ? '操作成功' :response.msg;
        layer.open({
            content : msg,
            end:function(){
                if(response.status >0){
                    table.reload('ad',{});
                layer.closeAll();
                }
            }
        });
        return false;
    },'JSON')
}

</script>

<!--format logo-->
<script type="text/html" id="logo">
    <a href="{{d.mer_logo}}" target="_blank"><img src="{{d.mer_logo}}" width="50"/></a>
</script>

<script type="text/html" id="tool">
    <i class="layui-icon lyui_icon_big" lay-event="edit" title="编辑">&#xe642;</i>
    <!-- <i class="layui-icon lyui_icon_big" lay-event="del" title="删除">&#xe640;</i> -->
</script>
