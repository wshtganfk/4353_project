<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:74:"D:\xampp\htdocs\zoemp\public/../application/admin\view\merchant\index.html";i:1565775271;s:64:"D:\xampp\htdocs\zoemp\application\admin\view\library\header.html";i:1552474293;s:62:"D:\xampp\htdocs\zoemp\application\admin\view\library\menu.html";i:1539761895;s:64:"D:\xampp\htdocs\zoemp\application\admin\view\library\footer.html";i:1531464212;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>影院广告管理</title>
    <link rel="stylesheet" href="/static/layui/css/layui.css">
    <script src="/static/js/jquery.min.js"></script>
    <script src="/static/layui/layui.js"></script>
    <script>
        var jquery,element;
        layui.use(['element', 'jquery'], function(){
            element = layui.element;
            jquery = layui.jquery;
        });

        function logout(){
            var param = {};
            jquery.post('/admin/login/doLogout', param,function(response){
                if( response.status > 0){
                    window.location.href = '/admin';
                    return true;
                }
            },'JSON')
        }
    </script>
</head>
<body class="layui-layout-body">
    <div class="layui-layout layui-layout-admin">
        <div class="layui-header">
            <div class="layui-logo">
                <img src="/static/images/nav-logo.png"/>
            </div>
            <!-- 头部区域（可配合layui已有的水平导航） -->
            <ul class="layui-nav layui-layout-right">
                <li class="layui-nav-item">
                    <a href="javascript:;">
                        <img src="http://t.cn/RCzsdCq" class="layui-nav-img">
                    <?php echo $admin['admin_name']; ?>
                    </a>
                </li>
                <li class="layui-nav-item"><a href="#" onclick="logout()">登出</a></li>
            </ul>
        </div>

<div class="layui-side layui-bg-black">
    <div class="layui-side-scroll">
        <!-- 左侧导航区域（可配合layui已有的垂直导航） -->
        <ul class="layui-nav layui-nav-tree"  lay-filter="test">
            <?php if($menu_list): foreach($menu_list as $menu): ?>
                    <li class="layui-nav-item layui-nav-itemed">
                        <a class="" href="javascript:;"><?php echo $menu['module_name']; ?></a>
                        <?php if($menu['parents'] != ""): ?>
                            <dl class="layui-nav-child">
                                <?php foreach($menu['parents'] as $childMenu): ?>
                                    <dd style="padding-left:1.2rem;" class="<?php if( stripos( $php_self, $childMenu['module_action']) !== false) echo 'layui-this'?>">
                                        <a href="<?php echo $childMenu['module_action']; ?>" ><?php echo $childMenu['module_name']; ?></a>
                                    </dd>
                                <?php endforeach; ?>
                            </dl>
                        <?php endif; ?>
                    </li>
                <?php endforeach; endif; ?>
          <!--   <li class="layui-nav-item layui-nav-itemed">
                <a class="" href="javascript:;">所有商品</a>
                <dl class="layui-nav-child">
                    <dd><a href="javascript:;">列表一</a></dd>
                    <dd><a href="javascript:;">列表二</a></dd>
                    <dd><a href="javascript:;">列表三</a></dd>
                    <dd><a href="">超链接</a></dd>
                </dl>
            </li>

            <li class="layui-nav-item">
                <a href="javascript:;">解决方案</a>
                <dl class="layui-nav-child">
                    <dd><a href="javascript:;">列表一</a></dd>
                    <dd><a href="javascript:;">列表二</a></dd>
                    <dd><a href="">超链接</a></dd>
                </dl>
            </li>
            
            <li class="layui-nav-item"><a href="">云市场</a></li>
            <li class="layui-nav-item"><a href="">发布商品</a></li> -->
      </ul>
    </div>
</div>

<style type="text/css">
    .layui-btn{background-color: #1e9fff;}
    .layui-input{width: 200px;}
    .layui-input-c{width: 400px;}
    .lyui_icon_big{font-size: 26px;color: #12a0ff;cursor: pointer;}
</style>>

<link rel="stylesheet" href="/static/css/multiple-select.css" />
<div class="layui-body" style="bottom: 0;">
    <!-- 内容主体区域 -->
    <div style="padding: 15px;">
        <div class="layui-row">
            <span class="layui-breadcrumb">
                <a href="/admin/index">首页</a>
                <a href="javascript:void(0)">商户列表</a>
            </span>
        </div>
        
        <div class="layui-row" style="padding-top: 15px;">
            <div class="layui-form" style="float:left;">
                <div class="layui-form-item">
                    <div class="layui-inline">
                        <label class="layui-form-label">名称：</label>
                        <div class="layui-input-block">
                          <input type="text" placeholder="商户编码|名称|简称" class="layui-input" id="keywords">
                        </div>
                    </div>
                
                    <div class="layui-inline">
                        <button class="layui-btn layui-btn-normal" onclick="search()">
                        <i class="layui-icon">&#xe615;</i>
                    </button>
                    </div>

                    
                </div>
            </div>
            <div style="float:right">
                <button class="layui-btn layui-btn-normal" style="margin-left: 25px;" onclick="dlgAdmin(0)">
                    添加
                </button>
            </div>
        </div>

        <div class="layui-row">
            <table id="merchant" lay-filter="merchant"></table>
        </div>

        
    </div>
</div>

<div id="form_detail" style="display: none;">
<form class="layui-form" action="">
    <div style="margin-top:15px;margin-left:15px;">
        <div class="layui-form-item">
            <div class="layui-block">
                <label class="layui-form-label">商户编码：</label>
                <div class="layui-input-block">
                  <input type="text" placeholder="请输入商户编码"  class="layui-input layui-input-c" id="mer_code">
                </div>
            </div>
        </div>
        <div class="layui-form-item">
            <div class="layui-block">
                <label class="layui-form-label">商户名称：</label>
                <div class="layui-input-block">
                  <input type="text" placeholder="请输入商户名称"  class="layui-input layui-input-c" id="mer_name">
                </div>
            </div>
        </div>

        <div class="layui-form-item">
            <div class="layui-block">
                <label class="layui-form-label">商户简称：</label>
                <div class="layui-input-block">
                  <input type="text" 
                         placeholder="请输入商户简称"  
                         class="layui-input layui-input-c"
                         id="mer_arv">
                </div>
            </div>
        </div>
        
        <div class="layui-form-item">
            <div class="layui-block">
                <label class="layui-form-label">商户LOGO：</label>
                <div class="layui-input-block">
                    <div class="layui-upload-drag" 
                         id="imageUpload" 
                         lay-verify="logo">
                        <i class="layui-icon"></i>
                        <p>点击上传，或将文件拖拽到此处</p>
                    </div>
                    <div style="float: right;">
                        <img src="" width="100%" id="logo_img" style="width: 240px;height: 135px;"/>
                    </div>
                  </button>
                </div>
            </div>
        </div>

        <div class="layui-form-item">
            <div class="layui-block">
                <label class="layui-form-label">CARD背景图：</label>
                <div class="layui-input-block">
                    <div class="layui-upload-drag" 
                         id="imageCardUrl" 
                         lay-verify="card_url">
                        <i class="layui-icon"></i>
                        <p>点击上传，或将文件拖拽到此处</p>
                    </div>&nbsp;&nbsp;(宽度*高度 634*380)
                    <div style="float: right;">
                        <img src="" width="100%" id="card_url" style="width: 240px;height: 135px;"/>
                    </div>
                  </button>
                </div>
            </div>
        </div>

        <div class="layui-form-item">
            <div class="layui-block">
                <label class="layui-form-label">影票转赠图：</label>
                <div class="layui-input-block">
                    <div class="layui-upload-drag" 
                         id="imageShareUrl" 
                         lay-verify="card_url">
                        <i class="layui-icon"></i>
                        <p>点击上传，或将文件拖拽到此处</p>
                    </div>&nbsp;&nbsp;(宽度*高度 400*320)
                    <div style="float: right;">
                        <img src="" width="100%" id="share_url" style="width: 240px;height: 135px;"/>
                    </div>
                  </button>
                </div>
            </div>
        </div>

        <div class="layui-form-item">
            <div class="layui-block">
                <label class="layui-form-label">验票机背景图：</label>
                <div class="layui-input-block">
                    <div class="layui-upload-drag" 
                         id="imageKioskUrl" 
                         lay-verify="card_url">
                        <i class="layui-icon"></i>
                        <p>点击上传，或将文件拖拽到此处</p>
                    </div>&nbsp;&nbsp;(宽度*高度 756*1370)
                    <div style="float: right;">
                        <img src="" width="100%" id="kiosk_bg_url" style="width: 240px;height: 135px;"/>
                    </div>
                  </button>
                </div>
            </div>
        </div>

        <div class="layui-form-item">
            <div class="layui-block">
                <label class="layui-form-label">取票机LOGO：</label>
                <div class="layui-input-block">
                    <div class="layui-upload-drag" 
                         id="imageKiosLogokUrl" 
                         lay-verify="card_url">
                        <i class="layui-icon"></i>
                        <p>点击上传，或将文件拖拽到此处</p>
                    </div>&nbsp;&nbsp;(宽度*高度 628*122)
                    <div style="float: right;">
                        <img src="" width="100%" id="kiosk_logo_url" style="width: 240px;height: 135px;"/>
                    </div>
                  </button>
                </div>
            </div>
        </div>

        <div class="layui-form-item">
            <div class="layui-block">
                <label class="layui-form-label">取票机提示图：</label>
                <div class="layui-input-block">
                    <div class="layui-upload-drag" 
                         id="imageKiosTipkUrl" 
                         lay-verify="card_url">
                        <i class="layui-icon"></i>
                        <p>点击上传，或将文件拖拽到此处</p>
                    </div>&nbsp;&nbsp;(宽度*高度 1080*111)
                    <div style="float: right;">
                        <img src="" width="100%" id="kiosk_tip_url" style="width: 240px;height: 135px;"/>
                    </div>
                  </button>
                </div>
            </div>
        </div>

        <div class="layui-form-item">
            <label class="layui-form-label">商户备注</label>
            <div class="layui-input-block">
                 <textarea placeholder="请输入商户备注" 
                           class="layui-textarea layui-input-c"
                           name="mer_description"
                           id="mer_description"
                           lay-verify=""></textarea>
            </div>
        </div>
    </div>  
    </form>
</div>
  

	</div>
</body>
</html>
<script src="/static/js/jquery.min.js"></script>
<script src="/static/js/multiple-select.js"></script>
<script>
var table,
    form,
    jquery,
    upload,
    mer_id;
var g_pkid = 0;

layui.use(['table','form', 'jquery','upload'], function(){
    table = layui.table;
    form = layui.form;
    jquery = layui.jquery;
    upload = layui.upload;

    jquery.ajaxSetup({
        async: false
    });
    //加载配置
    loadConfig();

    table.render({
        id : 'merchant',
        elem: '#merchant',
        height: jquery(window).height() - 185,
        url: '/admin/merchant/getListPage/',
        limits:  <?php  echo json_encode( config('paginate.page_list'))?>,
        limit: <?php  echo  config('paginate.list_rows')?>,
        page: true, //开启分页,
        loading : true,
        cols: [[ 
            {field: 'mer_id', title: '序号',width:80,align:'center'},
            {field: 'mer_name', title: '商户名称',align:'center'},
            {field: 'mer_arv', title: '商户简称',width : 170,align:'center'},
            {field: 'mer_logo', title: '商户LOGO',align:'center',templet: '#logo'},
            {field: 'is_card_insert', title: '是否插入卡包',align:'center',templet:function(d){
                var checked = d.is_insert_card > 0 ? 'checked' : '';
                return '<input type="checkbox" value="' + d.mer_id + '" lay-filter="isInsertCard" lay-skin="switch" lay-text="ON|OFF" '+ checked +'>';
            }},
            {field: 'status', title: '状态',align:'center',templet:function(d){
                var checked = d.status > 0 ? 'checked' : '';
                return '<input type="checkbox" value="' + d.mer_id + '" lay-filter="valid" lay-skin="switch" lay-text="ON|OFF" '+ checked +'>';
            }},
            {title:'操作',align:'center',width:120,toolbar:'#tool'}
        ]]
    });
      uploadSet('imageUpload','logo','logo_img');
      uploadSet('imageCardUrl','image','card_url');
      uploadSet('imageShareUrl','image','share_url');
      uploadSet('imageKioskUrl','image','kiosk_bg_url');
      uploadSet('imageKiosLogokUrl','image','kiosk_logo_url');
      uploadSet('imageKiosTipkUrl','image','kiosk_tip_url');

    table.on('tool(merchant)', function(obj){ //注：tool是工具条事件名，test是table原始容器的属性 lay-filter="对应的值"
        var data = obj.data; //获得当前行数据
        var layEvent = obj.event; //获得 lay-event 对应的值（也可以是表头的 event 参数对应的值）
        var tr = obj.tr; //获得当前行 tr 的DOM对象
        if( layEvent == 'edit'){
            dlgAdmin(data.mer_id);
        } else if(layEvent === 'del'){ //删除
            layer.confirm('您确定要删除广告名称 ['+ data.mer_name +'] 吗？', function(index){
                del(data);
                //obj.del(); //删除对应行（tr）的DOM结构，并更新缓存
                layer.close(index);
                //向服务端发送删除指令
            });
        }
    });

    form.on('switch(valid)', function(obj){
        toggleValid('status',obj.value);
    })

    form.on('switch(isInsertCard)', function(obj){
        toggleValid('is_insert_card',obj.value);
    })

    form.on('select(ad_type)', function(obj){
        if(obj.value == '10001001'){
            $("#videoUpload").show();
            $("#imageUpload").hide();
        } else {
            $("#videoUpload").hide();
            $("#imageUpload").show();
        }
    })
    
});


function uploadSet(ele,folder,preview){
    //设定文件大小限制
      upload.render({
        elem: '#'+ele
        ,url: '/admin/base/uploadImage/?dir='+folder
        ,size: 1024 //限制文件大小，单位 KB
        ,done: function(res){
          layer.open({
                content : res.msg,
                end:function(){
                    if( res.status >0){
                        $('#'+preview).attr('src', res.data.path);
                    }
                }
            })
        }
      });
}

function loadConfig(){
    var param = {};
    // param.methods = 'bank|merchant|group';
    param.methods = 'div';
    param.div_kind = 10001;
    $.post('/admin/merchant/getPageConfig', param, function(response){
        if( response.status > 0){
            //区分
            var div = response.data.div;
            var divOpt = '<option value="0">请选择类型</option>';
            for (var i = 0; i < div.length; i++) {
                divOpt += '<option value="'+ div[i].div_id +'">' + div[i].div_name + '</option>';
            };
            $('#dlg_ad_type').html(divOpt);
            form.render();
        }
    },'JSON');
}


function search(){
    table.reload('merchant',{
        where:{
            keywords : jquery('#keywords').val(),
        }
    });
}

function toggleValid(field,pkid){
    var param = {};
    param.mer_id = pkid;
    param.field = field;
    $.post('/admin/merchant/toggleValid', param, function(response){
        if( response.status > 0){
            table.reload('ad',{});
        }
    },'JSON')
}

function dlgAdmin(pkid){
    layer.open({
        title: '添加/编辑 商户',
        content: jquery('#form_detail'),
        type : 1,
        area: ['900px', '600px'],
        btn : ['保存','关闭'],
        yes:function(){
            save(pkid);
        },
        btn2:function(){
            
        },
        success:function(index){
            getRow(pkid)
        }

    });    
}

function getRow(pkid){
    pkid = pkid
    if( pkid){
        var param ={};
        param.mer_id = pkid
        $.post('/admin/merchant/getRow', param, function(response){
            if( response.status > 0){
                var row = response.data.row;
                initDlgAdmin( row);
            }
            
        },'JSON');
    }else{
        initDlgAdmin({});
    }
}

function initDlgAdmin(frm){
    //基本信息
    $('#mer_code').val( frm.mer_code ? frm.mer_code : '');
    $('#mer_name').val( frm.mer_name ? frm.mer_name : '');
    $('#mer_arv').val( frm.mer_arv ? frm.mer_arv : '');
    $('#mer_description').val( frm.mer_description ? frm.mer_description : '');

    $('#logo_img').attr('src', frm.mer_logo);
    $('#card_url').attr('src', frm.card_url);
    $('#share_url').attr('src', frm.share_url);
    $('#kiosk_bg_url').attr('src', frm.kiosk_bg_url);
    $('#kiosk_logo_url').attr('src', frm.kiosk_logo_url);
    $('#kiosk_tip_url').attr('src', frm.kiosk_tip_url);

    //form.render('select');
}

function save(pkid){
    var param = {};
    param.mer_id = pkid;
    param.mer_code = $.trim($('#mer_code').val());
    param.mer_name = $.trim($('#mer_name').val());
    param.mer_arv = $.trim($('#mer_arv').val());
    param.mer_description = $.trim($('#mer_description').val());

    param.mer_logo = $("#logo_img").attr('src');
    param.card_url = $("#card_url").attr('src');
    param.share_url = $("#share_url").attr('src');
    param.kiosk_bg_url = $("#kiosk_bg_url").attr('src');
    param.kiosk_logo_url = $("#kiosk_logo_url").attr('src');
    param.kiosk_tip_url = $("#kiosk_tip_url").attr('src');
    
    if(param.mer_code == ''){
        layer.alert("请输入商户编码");
        return;
    }

    if(param.mer_name == ''){
        layer.alert("请输入商户名称");
        return;
    }

    $.post('/admin/merchant/save', param, function(response){
        var msg  = response.status >0 ? '操作成功' :response.msg;
        layer.open({
            content : msg,
            end:function(){
                if(response.status >0){
                    table.reload('merchant',{});
                layer.closeAll();
                }
            }
        });
        return false;
    },'JSON')
}

function del(data){
    var param = {};
    param.ad_id = data.ad_id;
    if(data.ad_path)
        param.ad_path = data.ad_path;
    
    $.post('/admin/merchant/del', param, function(response){
        var msg  = response.status >0 ? '操作成功' :response.msg;
        layer.open({
            content : msg,
            end:function(){
                if(response.status >0){
                    table.reload('ad',{});
                layer.closeAll();
                }
            }
        });
        return false;
    },'JSON')
}

</script>

<!--format logo-->
<script type="text/html" id="logo">
    <a href="{{d.mer_logo}}" target="_blank"><img src="{{d.mer_logo}}" width="50"/></a>
</script>

<script type="text/html" id="tool">
    <i class="layui-icon lyui_icon_big" lay-event="edit" title="编辑">&#xe642;</i>
    <!-- <i class="layui-icon lyui_icon_big" lay-event="del" title="删除">&#xe640;</i> -->
</script>
