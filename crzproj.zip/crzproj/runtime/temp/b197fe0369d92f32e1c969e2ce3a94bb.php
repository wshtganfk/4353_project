<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:83:"D:\xampp\htdocs\zoemp\public/../application/admin\view\ticket_report_dtl\index.html";i:1555325684;s:64:"D:\xampp\htdocs\zoemp\application\admin\view\library\header.html";i:1552474293;s:62:"D:\xampp\htdocs\zoemp\application\admin\view\library\menu.html";i:1539761895;s:64:"D:\xampp\htdocs\zoemp\application\admin\view\library\footer.html";i:1531464212;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>影院广告管理</title>
    <link rel="stylesheet" href="/static/layui/css/layui.css">
    <script src="/static/js/jquery.min.js"></script>
    <script src="/static/layui/layui.js"></script>
    <script>
        var jquery,element;
        layui.use(['element', 'jquery'], function(){
            element = layui.element;
            jquery = layui.jquery;
        });

        function logout(){
            var param = {};
            jquery.post('/admin/login/doLogout', param,function(response){
                if( response.status > 0){
                    window.location.href = '/admin';
                    return true;
                }
            },'JSON')
        }
    </script>
</head>
<body class="layui-layout-body">
    <div class="layui-layout layui-layout-admin">
        <div class="layui-header">
            <div class="layui-logo">
                <img src="/static/images/nav-logo.png"/>
            </div>
            <!-- 头部区域（可配合layui已有的水平导航） -->
            <ul class="layui-nav layui-layout-right">
                <li class="layui-nav-item">
                    <a href="javascript:;">
                        <img src="http://t.cn/RCzsdCq" class="layui-nav-img">
                    <?php echo $admin['admin_name']; ?>
                    </a>
                </li>
                <li class="layui-nav-item"><a href="#" onclick="logout()">登出</a></li>
            </ul>
        </div>

<div class="layui-side layui-bg-black">
    <div class="layui-side-scroll">
        <!-- 左侧导航区域（可配合layui已有的垂直导航） -->
        <ul class="layui-nav layui-nav-tree"  lay-filter="test">
            <?php if($menu_list): foreach($menu_list as $menu): ?>
                    <li class="layui-nav-item layui-nav-itemed">
                        <a class="" href="javascript:;"><?php echo $menu['module_name']; ?></a>
                        <?php if($menu['parents'] != ""): ?>
                            <dl class="layui-nav-child">
                                <?php foreach($menu['parents'] as $childMenu): ?>
                                    <dd style="padding-left:1.2rem;" class="<?php if( stripos( $php_self, $childMenu['module_action']) !== false) echo 'layui-this'?>">
                                        <a href="<?php echo $childMenu['module_action']; ?>" ><?php echo $childMenu['module_name']; ?></a>
                                    </dd>
                                <?php endforeach; ?>
                            </dl>
                        <?php endif; ?>
                    </li>
                <?php endforeach; endif; ?>
          <!--   <li class="layui-nav-item layui-nav-itemed">
                <a class="" href="javascript:;">所有商品</a>
                <dl class="layui-nav-child">
                    <dd><a href="javascript:;">列表一</a></dd>
                    <dd><a href="javascript:;">列表二</a></dd>
                    <dd><a href="javascript:;">列表三</a></dd>
                    <dd><a href="">超链接</a></dd>
                </dl>
            </li>

            <li class="layui-nav-item">
                <a href="javascript:;">解决方案</a>
                <dl class="layui-nav-child">
                    <dd><a href="javascript:;">列表一</a></dd>
                    <dd><a href="javascript:;">列表二</a></dd>
                    <dd><a href="">超链接</a></dd>
                </dl>
            </li>
            
            <li class="layui-nav-item"><a href="">云市场</a></li>
            <li class="layui-nav-item"><a href="">发布商品</a></li> -->
      </ul>
    </div>
</div>

<style type="text/css">
    .layui-btn{background-color: #1e9fff;}
    .layui-input{width: 200px;}
    .layui-input-c{width: 400px;}
    .lyui_icon_big{font-size: 26px;color: #12a0ff;cursor: pointer;}
</style>>

<link rel="stylesheet" href="/static/css/multiple-select.css" />
<link rel="stylesheet" href="/static/css/selectmenu.css" type="text/css">
<div class="layui-body" style="bottom: 0;">
    <!-- 内容主体区域 -->
    <div style="padding: 15px;">
        <div class="layui-row">
            <span class="layui-breadcrumb">
                <a href="/">首页</a>
                <a href="javascript:void(0)">验票明细表</a>
            </span>
        </div>
        
        <div class="layui-row" style="padding-top: 15px;">
            <div class="layui-form" style="float:left;">
                <div class="layui-inline">
                    <label class="layui-form-label">日期范围：</label>
                    <div class="layui-input-inline">
                        <input type="text"  class="layui-input" placeholder="起始日期 至 结束日期" id="fetch_time_range">
                    </div>
                </div>
                <div class="layui-inline">
                    <label class="layui-form-label" style="padding: 9px 0;">商户：</label>
                    <div class="layui-input-inline">
                        <select name="mer_id" lay-filter="mer_select" lay-search id="mer_id">

                        </select>    
                    </div>
                </div>
                <div class="layui-inline">
                    <label class="layui-form-label" style="padding: 9px 0;">影城：</label>
                    <div class="layui-input-inline">
                        <input type="text" name="form_shop" placeholder="请选择门店,不选=所有" autocomplete="off" class="layui-input" onclick="dlgShop()">  
                    </div>
                </div>
                <button class="layui-btn layui-btn-normal" style="margin-left: 25px;" onclick="search()">
                    <i class="layui-icon">&#xe615;检索</i>
                </button>
                <button class="layui-btn layui-btn-normal" style="margin-left: 25px;" onclick="export_data()">
                    <i class="layui-icon">&#xe637;导出</i>
                </button>
            </div>
        </div>

        <div class="layui-row">
            <table id="scanqr" lay-filter="scanqr"></table>
        </div>

        
    </div>
</div>
  

	</div>
</body>
</html>
<script src="/static/js/jquery.min.js"></script>
<script src="/static/js/multiple-select.js"></script>
<script src="/static/js/selectmenu.min.js"></script>

<script>
var table,form,jquery,shop_ids,shop_data = [];
layui.use(['table','form', 'jquery','laydate'], function(){
    table = layui.table;
    form = layui.form;
    jquery = layui.jquery;
    laydate = layui.laydate;

    //日期范围
    laydate.render({
      elem: '#fetch_time_range'
      ,range: '~'
    });
    //加载配置
    loadConfig();

    table.render({
        id : 'scanqr',
        elem: '#scanqr',
        height: jquery(window).height() - 185,
        url: '/admin/TicketReportDtl/getListPage/',
        limits:  <?php  echo json_encode( config('paginate.page_list'))?>,
        limit: <?php  echo  config('paginate.list_rows')?>,
        page: true, //开启分页,
        loading : true,
        method : 'post',
        cols: [[ 
            {field: 'mer_name',fixed:'left', title: '商户名称',width:140,align:'center'},
            {field: 'shop_name',fixed:'left', title: '门店名称',width:140,align:'center'},
            {field: 'src_confirm_sn', title: '取票码',width:140,align:'center'},
            {field: 'verify_time_format', title: '验票时间',width : 170,align:'center'},
            {field: 'fetch_time_format', title: '取票时间',width : 170,align:'center'},
            {field: 'show_date_format', title: '放映时间',width : 170,align:'center'},
            {field: 'seller_name', title: '售票渠道',width:120,align:'center'},
            {field: 'mobile', title: '手机号',width:120,align:'center'},
            {field: 'film_num', title: '票数',align:'center'},
        ]]
    }); 

    form.on('select(mer_select)', function(data){
        var param = {};
        param.mer_ids = data.value;
        shop_data = [];
        $.post('/admin/cinema/cinemaList',param,function(response){
            if( response.status > 0 ){
                var shop_list = response.data.shop_list;
                for (var i = 0; i < shop_list.length; i++) {
                    shop_data.push(shop_list[i]);
                }
            }
        },'JSON');
    });   
});

function loadConfig(){
    var param = {};
    // param.methods = 'bank|merchant|group';
    param.methods = 'merchant|div';
    param.div_kind = 10001;
    jquery.post('/admin/base/getPageConfig', param, function(response){
        if( response.status > 0){
            //商户列表
            var merchant = response.data.merchant;

            var opt = '<option value="0">请选择商户</option>';
            for (var i = 0; i < merchant.length; i++) {
                opt += '<option value="'+ merchant[i].mer_id +'">' + merchant[i].mer_name + '</option>';
            };
            $('#mer_id').html(opt);
        
            form.render();
        }
    },'JSON');
}


function search(){
    table.reload('scanqr',{
        where:{
            fetch_time_range : jquery('#fetch_time_range').val(),
            mer_id : jquery('#mer_id').val(),
            shop_ids : shop_ids
        }
    });
}

function export_data(){
    var params = getParams();
    var url = '/admin/TicketReportDtl/export?';
    for( col in params){
        url += col + '=' + params[col] + '&';
    }
    url = url.substring(0, url.length - 1);
    window.open(url);
}

function getParams(){
    return {
        fetch_time_range : $('#fetch_time_range').val(),
        mer_id : $('#mer_id').val()
    };
}

function dlgShop(){
    $('input[name=form_shop]').selectMenu({
        showField : 'shop_name',
        keyField : 'shop_id',
        searchField : 'shop_name',
        data:function(){
            return shop_data;
        },
        multiple:true,
        title : '请选择门店',
        eSelect:function(data){
            var shopNames = '';
            var shopIds = '';
            $('.sm_results li.sm_selected').each(function(){
                shopIds += $(this).attr('pkey') + ',';
                shopNames += $(this).attr('title') + ',';
            });
            shopNames = shopNames.substring(0, shopNames.length - 1);
            shop_ids = shopIds.substring(0, shopIds.length - 1);
            $('input[name=form_shop]').val(shopNames);                           
        }

    });
    $('.sm_container').css('z-index',999999999);
    // $('.sm_results li').each(function(index, el) {
    //     var pkey = $(this).attr('pkey');        
    //     for (var i = 0; i < selectShop.length; i++) {
    //         if(selectShop[i].shop_id == pkey){
    //             $(this).addClass('sm_selected');
    //         }
    //     }
    // });
}

</script>

<script type="text/javascript" id="tool">
    <a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="edit"><i class="layui-icon layui-icon-search"></i>查看</a>
</script>
