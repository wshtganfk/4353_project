<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:73:"D:\xampp\htdocs\crzproj\public/../application/index\view\login\index.html";i:1587575482;}*/ ?>
<!DOCTYPE htm>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>Animated Login </title>
        <link rel ="stylesheet" href="/static/css/login.css">
        <link rel="stylesheet" href="/static/layui/css/layui.css">
    </head>
    <body>
        <form class="LG" action="" method="post">
            <h1>login</h1>
            <input type="text" name="username" id="username" placeholder="Username">
            <input type="password" name="password" id="password" placeholder="Password">
            <input type="button" id="btnLogin" name="btnLogin" value="Login">
            <a href="register.html">Don't have account? </a>
        </form>
     <script src="/static/js/jquery.min.js"></script>
     <script src="/static/layui/layui.js"></script>
     <script type="text/javascript">
        layui.use('form',function(){
            var form = layui.form;
        });
         $('#btnLogin').on('click',()=>{
            var username = $.trim($('#username').val());
            var password = $.trim($('#password').val());
            if(username == '') {
                layer.alert('please enter username'); 
                $('#username').focus();
                return false;
            }
            if(password == '') {
                layer.alert('please enter password'); 
                $('#password').focus();
                return false;
            }
            var fd = {};
            fd.username = username;
            fd.password = password;
            $.post('/index/index/doLogin', fd, function(res){
            console.log(res);
            if(res.code > 0){
                layer.alert(res.msg);    
                return false;
            }else{
                window.location.href = '/index/index/manage';
                return true;
            }
        },'JSON')
         })
     </script>
    </body>
</html>
