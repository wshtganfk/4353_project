<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"D:\xampp\htdocs\crzproj\public/../application/index\view\fuelQh\index.html";i:1587626775;}*/ ?>
<!DOCTYPE htm>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>Fule Quote History</title>
        <link rel ="stylesheet" href="/static/css/Fuel_QF.css">
        <link rel="stylesheet" href="/static/layui/css/layui.css">
    </head>
    <body>
        <form class="LG" action="login.html" method="post">
        <h1>Fuel Quote History</h1>
        <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <p><?php echo $vo['quote_date']; ?> Price : <?php echo $vo['suggested_price']; ?>$ per gallons</p>
        <?php endforeach; endif; else: echo "" ;endif; ?>

        <p class="view-history">
            <a href="fuelQf.html">back</a>
        </p>
        <input type="button" id="btnLogOut" name="btnLogOut" value="Logout">
        </form>

        <script src="/static/js/jquery.min.js"></script>
        <script src="/static/layui/layui.js"></script>
        <script type="text/javascript">
            layui.use('form',function(){
                var form = layui.form;
            });
            
            $('#btnLogOut').on('click',()=>{
                window.location.href = '/index/index/logOut';
                return true;
            })
        </script>
    </body>
</html>

