﻿# Host: localhost  (Version 5.5.5-10.1.32-MariaDB)
# Date: 2020-04-23 19:03:53
# Generator: MySQL-Front 6.1  (Build 1.26)


#
# Structure for table "m_client"
#

CREATE TABLE `m_client` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `fullname` varchar(50) DEFAULT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `address1` varchar(300) DEFAULT NULL,
  `address2` varchar(300) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `state` varchar(20) NOT NULL,
  `zipcode` varchar(20) DEFAULT NULL,
  `add_time` int(10) unsigned DEFAULT '0',
  `status` tinyint(1) unsigned DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

#
# Data for table "m_client"
#

INSERT INTO `m_client` VALUES (1,'admin','xulei2','e10adc3949ba59abbe56e057f20f883e','82751438@qq.com','112222','11222','1111','IN ','111111',1587573844,1),(2,'xulei','11','e10adc3949ba59abbe56e057f20f883e','xulei@126.com','111','111','111','MA','1111',1587627350,1);

#
# Structure for table "m_user_quote_history"
#

CREATE TABLE `m_user_quote_history` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `client_id` int(10) NOT NULL,
  `gallons` int(10) unsigned NOT NULL,
  `suggested_price` decimal(10,2) DEFAULT NULL,
  `quote_date` varchar(40) NOT NULL,
  `add_time` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `i_client_id` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "m_user_quote_history"
#

INSERT INTO `m_user_quote_history` VALUES (1,1,'111',1000,1.79,'2020-04-23',1587625226),(2,1,'111',1000,1.79,'2020-04-22',1587639780);
ALTER TABLE `m_user_quote_history` ADD `delivery_address` VARCHAR(200) NOT NULL AFTER `client_id`;